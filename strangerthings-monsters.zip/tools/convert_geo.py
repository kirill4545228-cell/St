#!/usr/bin/env python3
"""
Конвертер Bedrock geo.json + animation.json (формат GeckoLib/Blockbench) -> компактный JSON для мода.
Использование из Python: convert_geo(geo, anim, texture_png, out_name, assets_dir, rotation_mode, anim_map)
"""
import json, math, os, shutil

FACE_ORDER = ["down", "up", "north", "south", "west", "east"]

def tr_rot(r, mode):
    x, y, z = r
    return {"A": (-x, -y, z), "B": (x, -y, -z), "C": (x, y, z)}[mode]

def box_uv(u, v, w, h, d, mirror):
    f = {
        "north": (u + d, v + d, u + d + w, v + d + h),
        "east":  (u, v + d, u + d, v + d + h),
        "south": (u + 2 * d + w, v + d, u + 2 * d + 2 * w, v + d + h),
        "west":  (u + d + w, v + d, u + 2 * d + w, v + d + h),
        "up":    (u + d + w, v + d, u + d, v),
        "down":  (u + d + 2 * w, v, u + d + w, v + d),
    }
    if mirror:
        f = {k: (r[2], r[1], r[0], r[3]) for k, r in f.items()}
        f["east"], f["west"] = f["west"], f["east"]
    return f

def convert_geo(geo_path, anim_path, tex_path, out_name, assets, mode="A", anim_map=None, quiet=False):
    g = json.load(open(geo_path))
    geo = g["minecraft:geometry"][0]
    tw = float(geo["description"]["texture_width"]); th = float(geo["description"]["texture_height"])
    raw = geo["bones"]
    by_name = {b["name"]: b for b in raw}
    order = []
    def visit(b):
        if b["name"] in [o["name"] for o in order]: return
        p = b.get("parent")
        if p and p in by_name: visit(by_name[p])
        order.append(b)
    for b in raw: visit(b)
    idx = {}
    bones = []
    def add_bone(name, parent, pivot, rot):
        i = len(bones)
        bones.append({"n": name, "p": parent, "o": [round(-pivot[0], 4), round(pivot[1], 4), round(pivot[2], 4)],
                      "r": [round(v, 4) for v in tr_rot(rot, mode)], "c": []})
        return i
    for b in order:
        parent = idx.get(b.get("parent"), -1) if b.get("parent") else -1
        i = add_bone(b["name"], parent, b.get("pivot", [0, 0, 0]), b.get("rotation", [0, 0, 0]))
        idx[b["name"]] = i
        for k, c in enumerate(b.get("cubes", [])):
            ox, oy, oz = c["origin"]; w, h, d = c["size"]; inf = c.get("inflate", 0) or 0
            frm = [-(ox + w) - inf, oy - inf, oz - inf]; to = [-ox + inf, oy + h + inf, oz + d + inf]
            u, v = c["uv"] if isinstance(c.get("uv"), list) else (0, 0)
            fw, fh, fd = [int(math.floor(x + 1e-6)) for x in (w, h, d)]
            faces = box_uv(u, v, fw, fh, fd, bool(c.get("mirror", b.get("mirror", False))))
            uvs = []
            for fn in FACE_ORDER:
                u1, v1, u2, v2 = faces[fn]
                u1, u2, v1, v2 = u1 / tw, u2 / tw, v1 / th, v2 / th
                corners = [(u1, v1), (u1, v2), (u2, v2), (u2, v1)]
                uvs.append([round(x, 6) for p in corners for x in p])
            cube = {"f": [round(x, 4) for x in frm + to], "uv": uvs}
            rot = c.get("rotation", [0, 0, 0])
            if any(abs(x) > 1e-6 for x in rot):
                piv = c.get("pivot", [0, 0, 0])
                j = add_bone("%s#c%d" % (b["name"], k), i, piv, rot)
                bones[j]["c"].append(cube)
            else:
                bones[i]["c"].append(cube)

    anims = {}
    if anim_path:
        ad = json.load(open(anim_path))["animations"]
        for out_key, src in (anim_map or {}).items():
            short = src.split(".")[-1]
            a = next((v for k, v in ad.items() if k.split(".")[-1] == short), None)
            if a is None:
                if not quiet: print("  ! нет анимации", src); continue
                continue
            tracks = {}
            maxt = 0.0
            for bname, chs in a.get("bones", {}).items():
                if bname not in idx: continue
                t = {}
                for chn, key in (("rotation", "r"), ("position", "p"), ("scale", "s")):
                    if chn not in chs: continue
                    v = chs[chn]
                    kfs = []
                    if isinstance(v, dict) and not ("vector" in v or "post" in v or "pre" in v):
                        items = sorted(((float(tk), tv) for tk, tv in v.items()), key=lambda x: x[0])
                    else:
                        items = [(0.0, v)]
                    for tt, tv in items:
                        mode_i = 0
                        if isinstance(tv, dict):
                            if tv.get("lerp_mode") == "catmullrom": mode_i = 1
                            tv = tv.get("vector") or tv.get("post") or tv.get("pre")
                            if isinstance(tv, dict): tv = tv.get("vector")
                        if isinstance(tv, (int, float)): tv = [tv, tv, tv]
                        x, y, z = [float(q) if not isinstance(q, str) else 0.0 for q in tv]
                        if key == "r": x, y, z = tr_rot((x, y, z), mode)
                        elif key == "p": x = -x
                        kfs.append([round(tt, 4), round(x, 4), round(y, 4), round(z, 4), mode_i])
                        maxt = max(maxt, tt)
                    t[key] = kfs
                if t: tracks[str(idx[bname])] = t
            length = float(a.get("animation_length") or maxt or 1.0)
            loop = a.get("loop")
            loop = "loop" if loop is True else ("hold" if loop == "hold_on_last_frame" else "once")
            anims[out_key] = {"len": length, "loop": loop, "t": tracks}

    os.makedirs(assets + "/bbmodels", exist_ok=True); os.makedirs(assets + "/textures/entity", exist_ok=True)
    json.dump({"bones": bones, "anims": anims}, open(assets + "/bbmodels/%s.json" % out_name, "w"), separators=(",", ":"))
    shutil.copy(tex_path, assets + "/textures/entity/%s.png" % out_name)
    return bones, anims
