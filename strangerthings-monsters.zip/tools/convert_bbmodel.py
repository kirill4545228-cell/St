#!/usr/bin/env python3
"""
Конвертер .bbmodel (Blockbench) -> компактный JSON + PNG текстура для мода Stranger Things.

Использование:
  python3 tools/convert_bbmodel.py <файл.bbmodel> <имя_моба> [папка_assets]

Создаёт:
  <assets>/bbmodels/<имя_моба>.json
  <assets>/textures/entity/<имя_моба>.png
Печатает границы модели (для подбора хитбокса).
"""
import json, sys, os, base64, math
import numpy as np

FACE_ORDER = ["down", "up", "north", "south", "west", "east"]

def num(v):
    try:
        return float(v)
    except Exception:
        print("  ! нечисловое значение в анимации (моланг не поддерживается), считаю 0:", v)
        return 0.0

def convert(path, name, assets):
    d = json.load(open(path))
    tex = d["textures"][0]
    tw = float(tex.get("uv_width") or d["resolution"]["width"])
    th = float(tex.get("uv_height") or d["resolution"]["height"])
    els = {e["uuid"]: e for e in d["elements"]}

    bones = []          # flat DFS list
    uuid2idx = {}

    def walk(node, parent):
        idx = len(bones)
        uuid2idx[node["uuid"]] = idx
        b = {"n": node["name"], "p": parent,
             "o": [round(x, 4) for x in node["origin"]],
             "r": [round(x, 4) for x in node.get("rotation", [0, 0, 0])],
             "c": []}
        bones.append(b)
        for ch in node["children"]:
            if isinstance(ch, str):
                e = els[ch]
                if any(abs(x) > 1e-6 for x in e.get("rotation", [0, 0, 0])):
                    raise SystemExit("Куб %s повёрнут сам по себе — оберни его в группу (кость)" % e["name"])
                uvs = []
                for fn in FACE_ORDER:
                    f = e["faces"].get(fn)
                    if f is None or f.get("texture") is None or f.get("texture") is False:
                        uvs.append(None); continue
                    u1, v1, u2, v2 = f["uv"]
                    u1, u2 = u1 / tw, u2 / tw
                    v1, v2 = v1 / th, v2 / th
                    rot = int(f.get("rotation", 0)) % 360
                    corners = [(u1, v1), (u1, v2), (u2, v2), (u2, v1)]
                    k = (rot // 90) % 4
                    corners = corners[k:] + corners[:k]
                    uvs.append([round(c, 6) for p in corners for c in p])
                b["c"].append({"f": [round(x, 4) for x in e["from"] + e["to"]], "uv": uvs})
        for ch in node["children"]:
            if isinstance(ch, dict):
                walk(ch, idx)

    for n in d["outliner"]:
        if isinstance(n, dict):
            walk(n, -1)

    anims = {}
    for a in d.get("animations", []):
        aname = a["name"].split(".")[-1]
        tracks = {}
        for gid, an in a["animators"].items():
            if gid not in uuid2idx:
                continue
            bi = uuid2idx[gid]
            t = {}
            for kf in an.get("keyframes", []):
                ch = {"rotation": "r", "position": "p", "scale": "s"}.get(kf["channel"])
                if ch is None:
                    continue
                dp = kf["data_points"][0]
                mode = {"linear": 0, "catmullrom": 1, "step": 2}.get(kf.get("interpolation", "linear"), 0)
                t.setdefault(ch, []).append([round(float(kf["time"]), 4), round(num(dp.get("x", 0)), 4),
                                             round(num(dp.get("y", 0)), 4), round(num(dp.get("z", 0)), 4), mode])
            for ch in t:
                t[ch].sort(key=lambda r: r[0])
            if t:
                tracks[str(bi)] = t
        anims[aname] = {"len": float(a["length"]), "loop": a.get("loop", "once"), "t": tracks}

    out = {"bones": bones, "anims": anims}
    os.makedirs(assets + "/bbmodels", exist_ok=True)
    os.makedirs(assets + "/textures/entity", exist_ok=True)
    json.dump(out, open(assets + "/bbmodels/%s.json" % name, "w"), separators=(",", ":"))
    src = tex["source"].split(",", 1)[1]
    open(assets + "/textures/entity/%s.png" % name, "wb").write(base64.b64decode(src))
    return out

# ---------- диагностика: границы модели в позе покоя + первый кадр idle ----------
def Rm(r):
    a, b, g = [math.radians(x) for x in r]
    Rx = np.array([[1, 0, 0], [0, math.cos(a), -math.sin(a)], [0, math.sin(a), math.cos(a)]])
    Ry = np.array([[math.cos(b), 0, math.sin(b)], [0, 1, 0], [-math.sin(b), 0, math.cos(b)]])
    Rz = np.array([[math.cos(g), -math.sin(g), 0], [math.sin(g), math.cos(g), 0], [0, 0, 1]])
    return Rz @ Ry @ Rx

def bounds(model, animname=None):
    bones = model["bones"]
    add = {}
    if animname and animname in model["anims"]:
        for bi, t in model["anims"][animname]["t"].items():
            add[int(bi)] = {ch: np.array(k[0][1:4]) for ch, k in t.items()}
    def mat(i):
        b = bones[i]
        P = np.array(b["o"]); r = np.array(b["r"], float); pos = np.zeros(3); s = np.ones(3)
        if i in add:
            r = r + add[i].get("r", 0); pos = pos + add[i].get("p", 0)
            s = add[i].get("s", np.ones(3))
        M = np.eye(4); M[:3, 3] = P + pos
        R = np.eye(4); R[:3, :3] = Rm(r) @ np.diag(s)
        T = np.eye(4); T[:3, 3] = -P
        L = M @ R @ T
        return (mat(b["p"]) @ L) if b["p"] >= 0 else L
    pts = []
    for i, b in enumerate(bones):
        M = mat(i)
        for c in b["c"]:
            f = c["f"]
            for x in (f[0], f[3]):
                for y in (f[1], f[4]):
                    for z in (f[2], f[5]):
                        pts.append((M @ np.array([x, y, z, 1]))[:3])
    pts = np.array(pts)
    return pts.min(0), pts.max(0)

if __name__ == "__main__":
    path, name = sys.argv[1], sys.argv[2]
    assets = sys.argv[3] if len(sys.argv) > 3 else "src/main/resources/assets/strangerthings"
    m = convert(path, name, assets)
    print("==", name, "bones", len(m["bones"]), "cubes", sum(len(b["c"]) for b in m["bones"]),
          "anims", {k: v["len"] for k, v in m["anims"].items()})
    for an in (None, "idle", "bud", "walk"):
        if an is None or an in m["anims"]:
            lo, hi = bounds(m, an)
            print("  bounds (%s): min %s max %s  -> width %.2f blocks, depth %.2f, height %.2f" % (
                an or "rest", np.round(lo, 1), np.round(hi, 1), (hi[0]-lo[0])/16, (hi[2]-lo[2])/16, hi[1]/16))
