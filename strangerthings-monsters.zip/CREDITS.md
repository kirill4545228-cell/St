# Credits

**Pyro** — модели, текстуры и анимации мобов с суффиксом `_pyro`
(`demogorgon_pyro`, `demodog_pyro`, `mind_flayer_pyro`), взяты из мода «Demogorgon» (Forge 1.20.1)
и использованы в этом проекте **с разрешения автора** при условии указания авторства.

Models, textures and animations of the `*_pyro` mobs are by **Pyro**, used with the author's permission.
Please keep this credit in the mod description / on the download page.

Файлы: `assets/strangerthings/bbmodels/*_pyro.json`, `assets/strangerthings/textures/entity/*_pyro.png`.
Звуки из того мода сюда НЕ переносились (разрешение было на модели; в папке звуков есть и чужие песни).
