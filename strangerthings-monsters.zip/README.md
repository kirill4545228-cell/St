# Stranger Things — Fabric 1.20.1

## Что внутри
**Предметы и блоки**
- Рация (`walkie_talkie`) — шипит помехами при ПКМ.
  Крафт: ` N ` / `IRI` / `ICI` (N — железный самородок, I — слиток, R — красная пыль, C — медный слиток).
- Рождественские огни (`christmas_lights`) — светятся, переливаются, вешаются на стену.
  Крафт (2 шт.): `SSS` / `RYG` / `DDD` (нить, красный/жёлтый/зелёный краситель, светящаяся пыль).

**Монстры** (пока без Изнанки: только яйца призыва и `/summon strangerthings:<id>`)
| Моб | id | Способности |
|---|---|---|
| Демогоргон | `demogorgon` | охота в темноте (скорость при свете ≤7), рёв (Замедление+Тьма+Слабость в 18 блоках), укус лепестками (Иссушение + лечит его), урон от огня x2 |
| Демопёс | `demodog` | стая (до +Силы при 3+ рядом), вой (зовёт всех демопсов в 32 блоках), прыжок-удар, укус с Замедлением, чует раненых игроков (<50% HP) без видимости, мстит всей стаей |
| Пожиратель разума | `mind_flayer` | босс-бар, «власть над разумом» (притягивает + Тошнота/Тьма/Замедление), призыв демопсов при HP<70%, удар о землю (AoE), клешня (подброс), укус с лечением, аура Тьмы |

## Как это устроено (модели)
Модели монстров — это .bbmodel из Blockbench, преобразованные в
`assets/strangerthings/bbmodels/<id>.json` + `textures/entity/<id>.png`.
Анимации играются автоматически по именам: `idle`, `bud` (демопёс без цели), `walk`, `run`,
`attack*`, `roar`, `hurt`, `death`.
Обновил модель в Blockbench? Запусти:

    python3 tools/convert_bbmodel.py мой.bbmodel demogorgon      # или demodog / mind_flayer

и пересобери мод. Хитбоксы — в `ModEntities.java`.

## Сборка на GitHub
Залей проект (или этот zip) в репозиторий — `.github/workflows/build.yml` сам распакует и соберёт jar
(Actions → Artifacts).

## Если у тебя уже есть репозиторий мода
Скопируй `java/com/strangerthings/` (новые папки `entity/` и `client/`, файлы `ModEntities/ModItems/ModBlocks/ModSounds`),
папки `assets/strangerthings/`, `data/strangerthings/`, строку `"client"` из `fabric.mod.json`
и в `onInitialize()`: `ModSounds.register(); ModEntities.register(); ModBlocks.register(); ModItems.register();`.
Файлы `lang/*.json` — допиши ключи, не заменяй.
