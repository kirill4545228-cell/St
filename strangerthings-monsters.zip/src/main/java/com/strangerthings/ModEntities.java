package com.strangerthings;

import com.strangerthings.entity.DemodogEntity;
import com.strangerthings.entity.DemogorgonEntity;
import com.strangerthings.entity.MindFlayerEntity;
import com.strangerthings.entity.MonsterBase;
import com.strangerthings.entity.PyroDemodogEntity;
import com.strangerthings.entity.PyroDemogorgonEntity;
import com.strangerthings.entity.PyroMindFlayerEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModEntities {
    public static final EntityType<DemogorgonEntity> DEMOGORGON =
            register("demogorgon", DemogorgonEntity::new, 0.9f, 3.0f);
    public static final EntityType<DemodogEntity> DEMODOG =
            register("demodog", DemodogEntity::new, 1.1f, 1.5f);
    public static final EntityType<MindFlayerEntity> MIND_FLAYER =
            register("mind_flayer", MindFlayerEntity::new, 2.4f, 2.0f);

    // варианты с моделями автора Pyro (с его разрешения)
    public static final EntityType<PyroDemogorgonEntity> DEMOGORGON_PYRO =
            register("demogorgon_pyro", PyroDemogorgonEntity::new, 1.0f, 3.5f);
    public static final EntityType<PyroDemodogEntity> DEMODOG_PYRO =
            register("demodog_pyro", PyroDemodogEntity::new, 1.2f, 1.3f);
    public static final EntityType<PyroMindFlayerEntity> MIND_FLAYER_PYRO =
            register("mind_flayer_pyro", PyroMindFlayerEntity::new, 3.5f, 3.2f);

    private static <T extends MonsterBase> EntityType<T> register(String id, EntityType.EntityFactory<T> factory,
                                                                  float width, float height) {
        return Registry.register(Registries.ENTITY_TYPE, new Identifier(StrangerThingsMod.MOD_ID, id),
                EntityType.Builder.create(factory, SpawnGroup.MONSTER)
                        .setDimensions(width, height)
                        .maxTrackingRange(10)
                        .build(id));
    }

    public static void register() {
        FabricDefaultAttributeRegistry.register(DEMOGORGON, DemogorgonEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(DEMODOG, DemodogEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(MIND_FLAYER, MindFlayerEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(DEMOGORGON_PYRO, DemogorgonEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(DEMODOG_PYRO, DemodogEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(MIND_FLAYER_PYRO, MindFlayerEntity.createAttributes());
    }
}
