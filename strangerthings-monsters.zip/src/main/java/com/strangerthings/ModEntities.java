package com.strangerthings;

import com.strangerthings.entity.DemogorgonEntity;
import com.strangerthings.entity.DemodogEntity;
import com.strangerthings.entity.MindFlayerEntity;
import com.strangerthings.entity.DemobatEntity;
import com.strangerthings.entity.DemoslugEntity;
import com.strangerthings.entity.FlayedHumanEntity;
import com.strangerthings.entity.FlayedRatsEntity;
import com.strangerthings.entity.FlayedBitsEntity;
import com.strangerthings.entity.HospitalMonsterEntity;
import com.strangerthings.entity.MeatFlayerEntity;
import com.strangerthings.entity.VecnaEntity;
import com.strangerthings.entity.SporeShooterEntity;
import com.strangerthings.entity.DemodogNestEntity;
import com.strangerthings.entity.MonsterBase;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

/** Монстры мода. Модели, текстуры и анимации — автор Pyro (использовано с его разрешения, см. CREDITS.md). */
public class ModEntities {
    public static final EntityType<DemogorgonEntity> DEMOGORGON =
            register("demogorgon", DemogorgonEntity::new, 1.0f, 3.6f);
    public static final EntityType<DemodogEntity> DEMODOG =
            register("demodog", DemodogEntity::new, 1.2f, 1.3f);
    public static final EntityType<MindFlayerEntity> MIND_FLAYER =
            register("mind_flayer", MindFlayerEntity::new, 3.5f, 3.2f);
    public static final EntityType<DemobatEntity> DEMOBAT =
            register("demobat", DemobatEntity::new, 0.8f, 0.6f);
    public static final EntityType<DemoslugEntity> DEMOSLUG =
            register("demoslug", DemoslugEntity::new, 0.5f, 0.3f);
    public static final EntityType<FlayedHumanEntity> FLAYED_HUMAN =
            register("flayed_human", FlayedHumanEntity::new, 0.7f, 2.0f);
    public static final EntityType<FlayedRatsEntity> FLAYED_RATS =
            register("flayed_rats", FlayedRatsEntity::new, 0.5f, 0.4f);
    public static final EntityType<FlayedBitsEntity> FLAYED_BITS =
            register("flayed_bits", FlayedBitsEntity::new, 0.4f, 0.3f);
    public static final EntityType<HospitalMonsterEntity> HOSPITAL_MONSTER =
            register("hospital_monster", HospitalMonsterEntity::new, 1.8f, 1.3f);
    public static final EntityType<MeatFlayerEntity> MEAT_FLAYER =
            register("meat_flayer", MeatFlayerEntity::new, 3.0f, 2.0f);
    public static final EntityType<VecnaEntity> VECNA =
            register("vecna", VecnaEntity::new, 0.7f, 2.1f);
    public static final EntityType<SporeShooterEntity> SPORE_SHOOTER =
            register("spore_shooter", SporeShooterEntity::new, 0.7f, 0.7f);
    public static final EntityType<DemodogNestEntity> DEMODOG_NEST =
            register("demodog_nest", DemodogNestEntity::new, 1.1f, 0.6f);

    private static <T extends MonsterBase> EntityType<T> register(String id, EntityType.EntityFactory<T> factory,
                                                                  float width, float height) {
        return Registry.register(Registries.ENTITY_TYPE, new Identifier(StrangerThingsMod.MOD_ID, id),
                EntityType.Builder.create(factory, SpawnGroup.MONSTER)
                        .setDimensions(width, height)
                        .maxTrackingRange(10)
                        .build(id));
    }

    public static void register() {
        FabricDefaultAttributeRegistry.register(DEMOGORGON, DemogorgonEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(DEMODOG, DemodogEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(MIND_FLAYER, MindFlayerEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(DEMOBAT, DemobatEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(DEMOSLUG, DemoslugEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(FLAYED_HUMAN, FlayedHumanEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(FLAYED_RATS, FlayedRatsEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(FLAYED_BITS, FlayedBitsEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(HOSPITAL_MONSTER, HospitalMonsterEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(MEAT_FLAYER, MeatFlayerEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(VECNA, VecnaEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(SPORE_SHOOTER, SporeShooterEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(DEMODOG_NEST, DemodogNestEntity.createAttributes());
    }
}
