package com.strangerthings;

import com.strangerthings.entity.DemodogEntity;
import com.strangerthings.entity.DemogorgonEntity;
import com.strangerthings.entity.MindFlayerEntity;
import com.strangerthings.entity.MonsterBase;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModEntities {
    public static final EntityType<DemogorgonEntity> DEMOGORGON =
            register("demogorgon", DemogorgonEntity::new, 0.9f, 3.0f);
    public static final EntityType<DemodogEntity> DEMODOG =
            register("demodog", DemodogEntity::new, 1.1f, 1.5f);
    public static final EntityType<MindFlayerEntity> MIND_FLAYER =
            register("mind_flayer", MindFlayerEntity::new, 2.4f, 2.0f);

    private static <T extends MonsterBase> EntityType<T> register(String id, EntityType.EntityFactory<T> factory,
                                                                  float width, float height) {
        return Registry.register(Registries.ENTITY_TYPE, new Identifier(StrangerThingsMod.MOD_ID, id),
                EntityType.Builder.create(factory, SpawnGroup.MONSTER)
                        .setDimensions(width, height)
                        .maxTrackingRange(10)
                        .build(id));
    }

    public static void register() {
        FabricDefaultAttributeRegistry.register(DEMOGORGON, DemogorgonEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(DEMODOG, DemodogEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(MIND_FLAYER, MindFlayerEntity.createAttributes());
    }
}
