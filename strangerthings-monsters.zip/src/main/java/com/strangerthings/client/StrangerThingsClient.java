package com.strangerthings.client;

import com.strangerthings.ModEntities;
import com.strangerthings.client.bb.BBRenderer;
import com.strangerthings.entity.MonsterBase;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.entity.EntityType;

public class StrangerThingsClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        reg(ModEntities.DEMOGORGON, "demogorgon", 0.9f);
        reg(ModEntities.DEMODOG, "demodog", 0.9f);
        reg(ModEntities.MIND_FLAYER, "mind_flayer", 1.6f);
        reg(ModEntities.DEMOGORGON_PYRO, "demogorgon_pyro", 0.9f);
        reg(ModEntities.DEMODOG_PYRO, "demodog_pyro", 0.9f);
        reg(ModEntities.MIND_FLAYER_PYRO, "mind_flayer_pyro", 2.5f);
    }

    private static void reg(EntityType<? extends MonsterBase> type, String name, float shadow) {
        EntityRendererRegistry.<MonsterBase>register(type, ctx -> new BBRenderer(ctx, name, shadow));
    }
}
