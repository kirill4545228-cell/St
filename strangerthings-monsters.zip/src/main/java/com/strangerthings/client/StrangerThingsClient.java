package com.strangerthings.client;

import com.strangerthings.ModEntities;
import com.strangerthings.client.bb.BBRenderer;
import com.strangerthings.entity.MonsterBase;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.entity.EntityType;

public class StrangerThingsClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        reg(ModEntities.DEMOGORGON, "demogorgon", 0.9f);
        reg(ModEntities.DEMODOG, "demodog", 0.9f);
        reg(ModEntities.MIND_FLAYER, "mind_flayer", 2.5f);
        reg(ModEntities.DEMOBAT, "demobat", 0.4f);
        reg(ModEntities.DEMOSLUG, "demoslug", 0.3f);
        reg(ModEntities.FLAYED_HUMAN, "flayed_human", 0.5f);
        reg(ModEntities.FLAYED_RATS, "flayed_rats", 0.3f);
        reg(ModEntities.FLAYED_BITS, "flayed_bits", 0.2f);
        reg(ModEntities.HOSPITAL_MONSTER, "hospital_monster", 1.0f);
        reg(ModEntities.MEAT_FLAYER, "meat_flayer", 2.0f);
        reg(ModEntities.VECNA, "vecna", 0.5f);
        reg(ModEntities.SPORE_SHOOTER, "spore_shooter", 0.4f);
        reg(ModEntities.DEMODOG_NEST, "demodog_nest", 0.7f);
    }

    private static void reg(EntityType<? extends MonsterBase> type, String name, float shadow) {
        EntityRendererRegistry.<MonsterBase>register(type, ctx -> new BBRenderer(ctx, name, shadow));
    }
}
