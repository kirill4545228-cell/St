package com.strangerthings.client.bb;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.resource.ResourceManager;
import net.minecraft.util.Identifier;

import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Модель из Blockbench в компактном виде (см. tools/convert_bbmodel.py).
 * Кости, кубы с UV по граням и анимации (rotation / position / scale).
 */
public class BBData {
    public static class Cube {
        public final float[] box = new float[6];     // x0 y0 z0 x1 y1 z1 (в пикселях)
        public final float[][] uv = new float[6][];  // down, up, north, south, west, east (8 чисел или null)
    }

    public static class Bone {
        public String name;
        public int parent;
        public final float[] origin = new float[3];
        public final float[] rot = new float[3];
        public final List<Cube> cubes = new ArrayList<>();
        public int[] children = new int[0];
    }

    public static class Track {
        public float[][] rot;  // строки: time, x, y, z, mode
        public float[][] pos;
        public float[][] scl;
    }

    public static class Anim {
        public float length;
        public String loop;
        public Track[] tracks;
    }

    public Bone[] bones;
    public int[] roots;
    public final Map<String, Anim> anims = new HashMap<>();

    public int indexOf(String name) {
        for (int i = 0; i < this.bones.length; i++) {
            if (this.bones[i].name.equals(name)) {
                return i;
            }
        }
        return -1;
    }

    public static BBData load(ResourceManager manager, Identifier id) {
        try (Reader reader = manager.getResourceOrThrow(id).getReader()) {
            JsonObject root = JsonParser.parseReader(reader).getAsJsonObject();
            BBData data = new BBData();

            JsonArray ba = root.getAsJsonArray("bones");
            int n = ba.size();
            data.bones = new Bone[n];
            List<List<Integer>> kids = new ArrayList<>();
            List<Integer> rootList = new ArrayList<>();
            for (int i = 0; i < n; i++) {
                kids.add(new ArrayList<>());
            }
            for (int i = 0; i < n; i++) {
                JsonObject jb = ba.get(i).getAsJsonObject();
                Bone b = new Bone();
                b.name = jb.get("n").getAsString();
                b.parent = jb.get("p").getAsInt();
                readFloats(jb.getAsJsonArray("o"), b.origin);
                readFloats(jb.getAsJsonArray("r"), b.rot);
                for (JsonElement ce : jb.getAsJsonArray("c")) {
                    JsonObject jc = ce.getAsJsonObject();
                    Cube c = new Cube();
                    readFloats(jc.getAsJsonArray("f"), c.box);
                    JsonArray uvs = jc.getAsJsonArray("uv");
                    for (int f = 0; f < 6; f++) {
                        JsonElement fe = uvs.get(f);
                        if (!fe.isJsonNull()) {
                            c.uv[f] = new float[8];
                            readFloats(fe.getAsJsonArray(), c.uv[f]);
                        }
                    }
                    b.cubes.add(c);
                }
                data.bones[i] = b;
                if (b.parent < 0) {
                    rootList.add(i);
                } else {
                    kids.get(b.parent).add(i);
                }
            }
            for (int i = 0; i < n; i++) {
                data.bones[i].children = kids.get(i).stream().mapToInt(Integer::intValue).toArray();
            }
            data.roots = rootList.stream().mapToInt(Integer::intValue).toArray();

            JsonObject anims = root.getAsJsonObject("anims");
            for (Map.Entry<String, JsonElement> e : anims.entrySet()) {
                JsonObject ja = e.getValue().getAsJsonObject();
                Anim a = new Anim();
                a.length = ja.get("len").getAsFloat();
                a.loop = ja.get("loop").getAsString();
                a.tracks = new Track[n];
                for (Map.Entry<String, JsonElement> te : ja.getAsJsonObject("t").entrySet()) {
                    int bi = Integer.parseInt(te.getKey());
                    JsonObject jt = te.getValue().getAsJsonObject();
                    Track t = new Track();
                    t.rot = readRows(jt.getAsJsonArray("r"));
                    t.pos = readRows(jt.getAsJsonArray("p"));
                    t.scl = readRows(jt.getAsJsonArray("s"));
                    a.tracks[bi] = t;
                }
                data.anims.put(e.getKey(), a);
            }
            return data;
        } catch (IOException ex) {
            throw new RuntimeException("Не удалось загрузить модель " + id, ex);
        }
    }

    private static void readFloats(JsonArray arr, float[] out) {
        for (int i = 0; i < out.length; i++) {
            out[i] = arr.get(i).getAsFloat();
        }
    }

    private static float[][] readRows(JsonArray rows) {
        if (rows == null) {
            return null;
        }
        float[][] out = new float[rows.size()][];
        for (int i = 0; i < out.length; i++) {
            JsonArray r = rows.get(i).getAsJsonArray();
            out[i] = new float[r.size()];
            for (int j = 0; j < out[i].length; j++) {
                out[i][j] = r.get(j).getAsFloat();
            }
        }
        return out;
    }
}
