package com.strangerthings.client.bb;

import com.strangerthings.StrangerThingsMod;
import com.strangerthings.entity.MonsterBase;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.util.Identifier;

/** Один рендерер на всех монстров: имя модели = имя файлов bbmodels/<name>.json и textures/entity/<name>.png */
public class BBRenderer extends MobEntityRenderer<MonsterBase, BBModel> {
    private final Identifier texture;

    public BBRenderer(EntityRendererFactory.Context ctx, String name, float shadowRadius) {
        super(ctx, new BBModel(BBData.load(ctx.getResourceManager(),
                new Identifier(StrangerThingsMod.MOD_ID, "bbmodels/" + name + ".json"))), shadowRadius);
        this.texture = new Identifier(StrangerThingsMod.MOD_ID, "textures/entity/" + name + ".png");
    }

    @Override
    public Identifier getTexture(MonsterBase entity) {
        return this.texture;
    }

    /** Не заваливаем труп на бок — анимацию смерти играет сама модель. */
    @Override
    protected float getLyingAngle(MonsterBase entity) {
        return 0.0f;
    }
}
