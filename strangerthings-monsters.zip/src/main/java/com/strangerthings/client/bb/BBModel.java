package com.strangerthings.client.bb;

import com.strangerthings.entity.MonsterBase;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/**
 * Рисует модель из Blockbench и проигрывает её анимации.
 * Анимация выбирается автоматически: death > действие (attack/roar/...) > hurt > walk/run > idle (или bud).
 * Значения анимаций ДОБАВЛЯЮТСЯ к позе кости (как в Blockbench).
 */
public class BBModel extends EntityModel<MonsterBase> {
    // порядок граней: down, up, north, south, west, east
    private static final int[][][] CORNERS = {
            {{0, 0, 1}, {0, 0, 0}, {1, 0, 0}, {1, 0, 1}},
            {{0, 1, 0}, {0, 1, 1}, {1, 1, 1}, {1, 1, 0}},
            {{1, 1, 0}, {1, 0, 0}, {0, 0, 0}, {0, 1, 0}},
            {{0, 1, 1}, {0, 0, 1}, {1, 0, 1}, {1, 1, 1}},
            {{0, 1, 0}, {0, 0, 0}, {0, 0, 1}, {0, 1, 1}},
            {{1, 1, 1}, {1, 0, 1}, {1, 0, 0}, {1, 1, 0}}
    };
    private static final float[][] NORMALS = {
            {0, -1, 0}, {0, 1, 0}, {0, 0, -1}, {0, 0, 1}, {-1, 0, 0}, {1, 0, 0}
    };

    private final BBData data;
    private final int boneCount;
    private final float[] rot;
    private final float[] pos;
    private final float[] scl;
    private final float[] tmp = new float[3];
    private final int headBone;
    private boolean dead;

    public BBModel(BBData data) {
        super(RenderLayer::getEntityCutoutNoCull);
        this.data = data;
        this.boneCount = data.bones.length;
        this.rot = new float[boneCount * 3];
        this.pos = new float[boneCount * 3];
        this.scl = new float[boneCount * 3];
        this.headBone = data.indexOf("head");
    }

    @Override
    public void setAngles(MonsterBase e, float limbAngle, float limbDistance, float animProgress,
                          float headYaw, float headPitch) {
        for (int i = 0; i < boneCount; i++) {
            BBData.Bone b = data.bones[i];
            for (int k = 0; k < 3; k++) {
                rot[i * 3 + k] = b.rot[k];
                pos[i * 3 + k] = 0f;
                scl[i * 3 + k] = 1f;
            }
        }
        float frac = animProgress - e.age;
        this.dead = e.isDead();
        String action = e.getAction();

        BBData.Anim anim = null;
        float time = 0f;
        if (dead && data.anims.containsKey("death")) {
            anim = data.anims.get("death");
            time = (e.deathTime + frac) / 20f;
        } else if (!dead && !action.isEmpty() && data.anims.containsKey(action)) {
            anim = data.anims.get(action);
            time = (animProgress - e.clientActionStart) / 20f;
        } else if (!dead && e.hurtTime > 0 && data.anims.containsKey("hurt")) {
            anim = data.anims.get("hurt");
            time = (e.maxHurtTime - e.hurtTime + frac) / 20f;
        } else if (!dead && limbDistance > 0.04f) {
            String name = (limbDistance > 0.7f && data.anims.containsKey("run")) ? "run" : "walk";
            anim = data.anims.get(name);
            if (anim != null) {
                float cycle = (limbAngle * 0.6662f) / (float) (Math.PI * 2.0);
                time = (cycle - (float) Math.floor(cycle)) * anim.length;
            }
        } else if (!dead) {
            String name = (!e.isHunting() && data.anims.containsKey("bud")) ? "bud" : "idle";
            anim = data.anims.get(name);
            time = animProgress / 20f;
        }
        if (anim != null && anim.length > 0f) {
            apply(anim, time);
        }

        // голова следит за целью
        if (!dead && headBone >= 0 && action.isEmpty()) {
            rot[headBone * 3 + 1] += -clamp(headYaw, -40f, 40f);
            rot[headBone * 3] += -clamp(headPitch, -30f, 30f);
        }
    }

    private static float clamp(float v, float lo, float hi) {
        return v < lo ? lo : Math.min(v, hi);
    }

    private void apply(BBData.Anim anim, float time) {
        boolean loop = "loop".equals(anim.loop);
        if (loop) {
            time = time % anim.length;
            if (time < 0f) {
                time += anim.length;
            }
        } else if (time > anim.length) {
            time = anim.length;
        } else if (time < 0f) {
            time = 0f;
        }
        for (int i = 0; i < boneCount; i++) {
            BBData.Track t = anim.tracks[i];
            if (t == null) {
                continue;
            }
            if (t.rot != null) {
                sample(t.rot, time, loop);
                rot[i * 3] += tmp[0];
                rot[i * 3 + 1] += tmp[1];
                rot[i * 3 + 2] += tmp[2];
            }
            if (t.pos != null) {
                sample(t.pos, time, loop);
                pos[i * 3] += tmp[0];
                pos[i * 3 + 1] += tmp[1];
                pos[i * 3 + 2] += tmp[2];
            }
            if (t.scl != null) {
                sample(t.scl, time, loop);
                scl[i * 3] *= tmp[0];
                scl[i * 3 + 1] *= tmp[1];
                scl[i * 3 + 2] *= tmp[2];
            }
        }
    }

    /** Значение трека в момент time -> tmp. */
    private void sample(float[][] k, float time, boolean loop) {
        int n = k.length;
        if (n == 1 || time <= k[0][0]) {
            copy(k[0]);
            return;
        }
        int i = 0;
        while (i < n - 1 && time >= k[i + 1][0]) {
            i++;
        }
        if (i >= n - 1) {
            copy(k[n - 1]);
            return;
        }
        float[] a = k[i];
        float[] b = k[i + 1];
        float f = (time - a[0]) / (b[0] - a[0]);
        int modeA = (int) a[4];
        int modeB = (int) b[4];
        if (modeB == 2) {
            copy(a);
            return;
        }
        if (modeA == 1 || modeB == 1) {
            float[] p0 = k[i > 0 ? i - 1 : (loop && n > 2 ? n - 2 : 0)];
            float[] p3 = k[i + 2 < n ? i + 2 : (loop && n > 2 ? 1 : n - 1)];
            float f2 = f * f;
            float f3 = f2 * f;
            for (int c = 0; c < 3; c++) {
                float v0 = p0[c + 1];
                float v1 = a[c + 1];
                float v2 = b[c + 1];
                float v3 = p3[c + 1];
                tmp[c] = 0.5f * ((2f * v1) + (-v0 + v2) * f
                        + (2f * v0 - 5f * v1 + 4f * v2 - v3) * f2
                        + (-v0 + 3f * v1 - 3f * v2 + v3) * f3);
            }
        } else {
            for (int c = 0; c < 3; c++) {
                tmp[c] = a[c + 1] + (b[c + 1] - a[c + 1]) * f;
            }
        }
    }

    private void copy(float[] row) {
        tmp[0] = row[1];
        tmp[1] = row[2];
        tmp[2] = row[3];
    }

    @Override
    public void render(MatrixStack matrices, VertexConsumer vc, int light, int overlay,
                       float r, float g, float b, float a) {
        int ov = dead ? OverlayTexture.DEFAULT_UV : overlay;
        matrices.push();
        // перевод из системы Blockbench (y вверх, перёд = -z) в систему рендера сущностей
        matrices.translate(0.0, 1.501, 0.0);
        matrices.scale(-1f, -1f, 1f);
        for (int root : data.roots) {
            drawBone(root, matrices, vc, light, ov, r, g, b, a);
        }
        matrices.pop();
    }

    private void drawBone(int i, MatrixStack m, VertexConsumer vc, int light, int overlay,
                          float r, float g, float b, float a) {
        BBData.Bone bone = data.bones[i];
        m.push();
        float ox = bone.origin[0] / 16f;
        float oy = bone.origin[1] / 16f;
        float oz = bone.origin[2] / 16f;
        m.translate(ox + pos[i * 3] / 16f, oy + pos[i * 3 + 1] / 16f, oz + pos[i * 3 + 2] / 16f);
        m.multiply(new Quaternionf().rotationZYX(
                (float) Math.toRadians(rot[i * 3 + 2]),
                (float) Math.toRadians(rot[i * 3 + 1]),
                (float) Math.toRadians(rot[i * 3])));
        m.scale(safe(scl[i * 3]), safe(scl[i * 3 + 1]), safe(scl[i * 3 + 2]));
        m.translate(-ox, -oy, -oz);

        if (!bone.cubes.isEmpty()) {
            MatrixStack.Entry entry = m.peek();
            Matrix4f pm = entry.getPositionMatrix();
            Matrix3f nm = entry.getNormalMatrix();
            for (BBData.Cube c : bone.cubes) {
                drawCube(c, pm, nm, vc, light, overlay, r, g, b, a);
            }
        }
        for (int child : bone.children) {
            drawBone(child, m, vc, light, overlay, r, g, b, a);
        }
        m.pop();
    }

    private static float safe(float s) {
        return Math.abs(s) < 0.001f ? 0.001f : s;
    }

    private void drawCube(BBData.Cube c, Matrix4f pm, Matrix3f nm, VertexConsumer vc, int light, int overlay,
                          float r, float g, float b, float a) {
        float[] bx = c.box;
        Vector3f n = new Vector3f();
        for (int f = 0; f < 6; f++) {
            float[] uv = c.uv[f];
            if (uv == null) {
                continue;
            }
            n.set(NORMALS[f][0], NORMALS[f][1], NORMALS[f][2]);
            nm.transform(n);
            n.normalize();
            for (int v = 0; v < 4; v++) {
                int[] cr = CORNERS[f][v];
                float x = (cr[0] == 0 ? bx[0] : bx[3]) / 16f;
                float y = (cr[1] == 0 ? bx[1] : bx[4]) / 16f;
                float z = (cr[2] == 0 ? bx[2] : bx[5]) / 16f;
                vc.vertex(pm, x, y, z)
                        .color(r, g, b, a)
                        .texture(uv[v * 2], uv[v * 2 + 1])
                        .overlay(overlay)
                        .light(light)
                        .normal(n.x, n.y, n.z)
                        .next();
            }
        }
    }
}
