package com.strangerthings;

import com.strangerthings.block.ChristmasLightsBlock;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.MapColor;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.util.Identifier;

public class ModBlocks {
    /** Светится на уровне 12 (макс. 15), цвета лампочек переливаются анимированной текстурой. */
    public static final Block CHRISTMAS_LIGHTS = Registry.register(Registries.BLOCK,
            new Identifier(StrangerThingsMod.MOD_ID, "christmas_lights"),
            new ChristmasLightsBlock(AbstractBlock.Settings.create()
                    .mapColor(MapColor.YELLOW)
                    .noCollision()
                    .nonOpaque()
                    .strength(0.2f)
                    .sounds(BlockSoundGroup.WOOL)
                    .luminance(state -> 12)));

    public static final Item CHRISTMAS_LIGHTS_ITEM = Registry.register(Registries.ITEM,
            new Identifier(StrangerThingsMod.MOD_ID, "christmas_lights"),
            new BlockItem(CHRISTMAS_LIGHTS, new FabricItemSettings()));

    public static void register() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.FUNCTIONAL)
                .register(entries -> entries.add(CHRISTMAS_LIGHTS_ITEM));
    }
}
