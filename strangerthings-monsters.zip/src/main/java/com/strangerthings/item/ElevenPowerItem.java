package com.strangerthings.item;

import com.strangerthings.ModEntities;
import com.strangerthings.entity.RiftPortalEntity;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.UseAction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * СИЛЫ ОДИННАДЦАТЬ.
 *  • Удерживай ПКМ: короткое (меньше 2,5 с) — телекинетический толчок вперёд.
 *  • Удерживай полные 2,5 с — открывается трещина в Изнанку (из Изнанки — обратно в обычный мир).
 *  • Каждое применение даёт «кровь из носа» (немного урона), поэтому есть перезарядка.
 */
public class ElevenPowerItem extends Item {
    private static final int CHARGE_TICKS = 50;

    public ElevenPowerItem(Settings settings) {
        super(settings);
    }

    @Override
    public UseAction getUseAction(ItemStack stack) {
        return UseAction.BOW;
    }

    @Override
    public int getMaxUseTime(ItemStack stack) {
        return 72000;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (user.getItemCooldownManager().isCoolingDown(this)) {
            return TypedActionResult.fail(stack);
        }
        user.setCurrentHand(hand);
        return TypedActionResult.consume(stack);
    }

    @Override
    public void usageTick(World world, LivingEntity user, ItemStack stack, int remainingUseTicks) {
        int used = this.getMaxUseTime(stack) - remainingUseTicks;
        if (world.isClient()) {
            double a = world.getRandom().nextDouble() * Math.PI * 2.0;
            double r = 1.2 - Math.min(1.0, used / (double) CHARGE_TICKS);
            world.addParticle(ParticleTypes.REVERSE_PORTAL,
                    user.getX() + Math.cos(a) * r, user.getY() + 0.3 + world.getRandom().nextDouble() * 1.4,
                    user.getZ() + Math.sin(a) * r, 0.0, 0.02, 0.0);
        } else if (used % 10 == 0) {
            world.playSound(null, user.getBlockPos(), SoundEvents.BLOCK_BEACON_AMBIENT, SoundCategory.PLAYERS,
                    0.6f, 0.5f + used / 120.0f);
        }
    }

    @Override
    public void onStoppedUsing(ItemStack stack, World world, LivingEntity user, int remainingUseTicks) {
        if (world.isClient() || !(user instanceof PlayerEntity player)) {
            return;
        }
        int used = this.getMaxUseTime(stack) - remainingUseTicks;
        if (used >= CHARGE_TICKS) {
            this.openRift(world, player);
        } else if (used >= 6) {
            this.push(world, player);
        }
    }

    private void nosebleed(PlayerEntity player, float damage) {
        if (player.getHealth() > damage + 2.0f) {
            player.damage(player.getDamageSources().magic(), damage);
        }
    }

    private void push(World world, PlayerEntity player) {
        Vec3d look = player.getRotationVec(1.0f).normalize();
        world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_WARDEN_SONIC_BOOM, SoundCategory.PLAYERS, 0.6f, 1.4f);
        for (LivingEntity e : world.getEntitiesByClass(LivingEntity.class, player.getBoundingBox().expand(9.0),
                x -> x != player && x.isAlive())) {
            Vec3d to = e.getPos().subtract(player.getPos());
            if (to.length() < 0.01 || look.dotProduct(to.normalize()) < 0.55) {
                continue;
            }
            e.takeKnockback(1.7, -look.x, -look.z);
            e.setVelocity(e.getVelocity().add(0.0, 0.3, 0.0));
            e.velocityModified = true;
            e.damage(player.getDamageSources().magic(), 4.0f);
            e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 40, 1));
        }
        this.nosebleed(player, 1.0f);
        player.getItemCooldownManager().set(this, 60);
    }

    private void openRift(World world, PlayerEntity player) {
        Vec3d look = player.getRotationVec(1.0f);
        Vec3d flat = new Vec3d(look.x, 0.0, look.z).normalize();
        Vec3d p = player.getPos().add(flat.multiply(2.6));
        BlockPos bp = BlockPos.ofFloored(p.x, player.getY() + 1.0, p.z);
        // ищем пол: идём вниз, пока под ногами воздух
        for (int i = 0; i < 6 && world.getBlockState(bp.down()).isAir(); i++) {
            bp = bp.down();
        }
        RiftPortalEntity portal = ModEntities.RIFT_PORTAL.create(world);
        if (portal == null) {
            return;
        }
        portal.refreshPositionAndAngles(bp.getX() + 0.5, bp.getY(), bp.getZ() + 0.5, player.getYaw() + 90.0f, 0.0f);
        portal.setLife(1200);
        world.spawnEntity(portal);
        world.playSound(null, bp, SoundEvents.BLOCK_PORTAL_AMBIENT, SoundCategory.PLAYERS, 1.0f, 0.6f);
        player.sendMessage(Text.translatable("message.strangerthings.rift_opened").formatted(Formatting.DARK_RED), true);
        this.nosebleed(player, 2.0f);
        player.getItemCooldownManager().set(this, 200);
    }

    @Override
    public void appendTooltip(ItemStack stack, @Nullable World world, List<Text> tooltip, TooltipContext context) {
        tooltip.add(Text.translatable("item.strangerthings.eleven_power.tooltip.0").formatted(Formatting.GRAY));
        tooltip.add(Text.translatable("item.strangerthings.eleven_power.tooltip.1").formatted(Formatting.DARK_RED));
    }
}
