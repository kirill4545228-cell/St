package com.strangerthings.item;

import com.strangerthings.ModSounds;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class WalkieTalkieItem extends Item {
    private static final int COOLDOWN_TICKS = 40;
    private static final int MESSAGE_VARIANTS = 3;

    public WalkieTalkieItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);

        if (user.getItemCooldownManager().isCoolingDown(this)) {
            return TypedActionResult.fail(stack);
        }
        user.getItemCooldownManager().set(this, COOLDOWN_TICKS);

        if (!world.isClient) {
            float pitch = 0.9f + world.random.nextFloat() * 0.2f;
            world.playSound(null, user.getX(), user.getY(), user.getZ(),
                    ModSounds.WALKIE_STATIC, SoundCategory.PLAYERS, 1.0f, pitch);

            if (world instanceof ServerWorld serverWorld) {
                serverWorld.spawnParticles(ParticleTypes.ELECTRIC_SPARK,
                        user.getX(), user.getEyeY() - 0.2, user.getZ(),
                        6, 0.25, 0.2, 0.25, 0.02);
            }

            int variant = world.random.nextInt(MESSAGE_VARIANTS);
            user.sendMessage(Text.translatable("item.strangerthings.walkie_talkie.static." + variant)
                    .formatted(Formatting.GRAY, Formatting.ITALIC), true);
        }

        return TypedActionResult.success(stack, world.isClient());
    }

    @Override
    public void appendTooltip(ItemStack stack, @Nullable World world, List<Text> tooltip, TooltipContext context) {
        tooltip.add(Text.translatable("item.strangerthings.walkie_talkie.tooltip").formatted(Formatting.GRAY));
    }
}
