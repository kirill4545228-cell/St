package com.strangerthings;

import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

public class ModSounds {
    public static final SoundEvent WALKIE_STATIC = register("item.walkie_talkie.static");

    private static SoundEvent register(String name) {
        Identifier id = new Identifier(StrangerThingsMod.MOD_ID, name);
        return Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
    }

    /** Вызов нужен, чтобы класс загрузился и звуки зарегистрировались. */
    public static void register() {
    }
}
