package com.strangerthings;

import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;

public class ModDimensions {
    /** Изнанка. Описание измерения лежит в data/strangerthings/dimension/upside_down.json */
    public static final RegistryKey<World> UPSIDE_DOWN =
            RegistryKey.of(RegistryKeys.WORLD, new Identifier(StrangerThingsMod.MOD_ID, "upside_down"));
}
