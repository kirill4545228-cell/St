package com.strangerthings;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class StrangerThingsMod implements ModInitializer {
    public static final String MOD_ID = "strangerthings";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModSounds.register();
        ModEntities.register();
        ModBlocks.register();
        ModItems.register();
        LOGGER.info("Stranger Things: рация, гирлянда и монстры зарегистрированы");
    }
}
