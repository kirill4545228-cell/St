package com.strangerthings;

import com.strangerthings.item.WalkieTalkieItem;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModItems {
    public static final Item WALKIE_TALKIE = register("walkie_talkie",
            new WalkieTalkieItem(new FabricItemSettings().maxCount(1)));

    public static final Item DEMOGORGON_SPAWN_EGG = register("demogorgon_spawn_egg",
            new SpawnEggItem(ModEntities.DEMOGORGON, 0x8A897D, 0xA85A58, new FabricItemSettings()));
    public static final Item DEMODOG_SPAWN_EGG = register("demodog_spawn_egg",
            new SpawnEggItem(ModEntities.DEMODOG, 0x6F6F66, 0xC24A4A, new FabricItemSettings()));
    public static final Item MIND_FLAYER_SPAWN_EGG = register("mind_flayer_spawn_egg",
            new SpawnEggItem(ModEntities.MIND_FLAYER, 0x1B1A24, 0x8B1A1A, new FabricItemSettings()));

    private static Item register(String name, Item item) {
        return Registry.register(Registries.ITEM, new Identifier(StrangerThingsMod.MOD_ID, name), item);
    }

    public static void register() {
        // Рация лежит во вкладке «Инструменты и утилиты».
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS)
                .register(entries -> entries.add(WALKIE_TALKIE));
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.SPAWN_EGGS).register(entries -> {
            entries.add(DEMOGORGON_SPAWN_EGG);
            entries.add(DEMODOG_SPAWN_EGG);
            entries.add(MIND_FLAYER_SPAWN_EGG);
        });
    }
}
