package com.strangerthings;

import com.strangerthings.item.WalkieTalkieItem;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModItems {
    public static final Item WALKIE_TALKIE = register("walkie_talkie",
            new WalkieTalkieItem(new FabricItemSettings().maxCount(1)));

    public static final Item DEMOGORGON_SPAWN_EGG = register("demogorgon_spawn_egg",
            new SpawnEggItem(ModEntities.DEMOGORGON, 0xB98C7A, 0x4A2A22, new FabricItemSettings()));
    public static final Item DEMODOG_SPAWN_EGG = register("demodog_spawn_egg",
            new SpawnEggItem(ModEntities.DEMODOG, 0x8A6A66, 0x3B2020, new FabricItemSettings()));
    public static final Item MIND_FLAYER_SPAWN_EGG = register("mind_flayer_spawn_egg",
            new SpawnEggItem(ModEntities.MIND_FLAYER, 0x2A0F14, 0xC0392B, new FabricItemSettings()));
    public static final Item DEMOBAT_SPAWN_EGG = register("demobat_spawn_egg",
            new SpawnEggItem(ModEntities.DEMOBAT, 0x6B3B3B, 0xD2A679, new FabricItemSettings()));
    public static final Item DEMOSLUG_SPAWN_EGG = register("demoslug_spawn_egg",
            new SpawnEggItem(ModEntities.DEMOSLUG, 0x7A6A52, 0x9BD36B, new FabricItemSettings()));
    public static final Item FLAYED_HUMAN_SPAWN_EGG = register("flayed_human_spawn_egg",
            new SpawnEggItem(ModEntities.FLAYED_HUMAN, 0x9C7B6B, 0x7A1F1F, new FabricItemSettings()));
    public static final Item FLAYED_RATS_SPAWN_EGG = register("flayed_rats_spawn_egg",
            new SpawnEggItem(ModEntities.FLAYED_RATS, 0x5E4B45, 0xB5473E, new FabricItemSettings()));
    public static final Item FLAYED_BITS_SPAWN_EGG = register("flayed_bits_spawn_egg",
            new SpawnEggItem(ModEntities.FLAYED_BITS, 0xA8564B, 0x4B1E1E, new FabricItemSettings()));
    public static final Item HOSPITAL_MONSTER_SPAWN_EGG = register("hospital_monster_spawn_egg",
            new SpawnEggItem(ModEntities.HOSPITAL_MONSTER, 0x8E8E7A, 0xB03A48, new FabricItemSettings()));
    public static final Item MEAT_FLAYER_SPAWN_EGG = register("meat_flayer_spawn_egg",
            new SpawnEggItem(ModEntities.MEAT_FLAYER, 0x7A2323, 0xD88A8A, new FabricItemSettings()));
    public static final Item VECNA_SPAWN_EGG = register("vecna_spawn_egg",
            new SpawnEggItem(ModEntities.VECNA, 0x3A2B3F, 0xC0392B, new FabricItemSettings()));
    public static final Item SPORE_SHOOTER_SPAWN_EGG = register("spore_shooter_spawn_egg",
            new SpawnEggItem(ModEntities.SPORE_SHOOTER, 0x6F8F4A, 0xE0C34A, new FabricItemSettings()));
    public static final Item DEMODOG_NEST_SPAWN_EGG = register("demodog_nest_spawn_egg",
            new SpawnEggItem(ModEntities.DEMODOG_NEST, 0x6A4A3A, 0xC24A4A, new FabricItemSettings()));

    private static Item register(String name, Item item) {
        return Registry.register(Registries.ITEM, new Identifier(StrangerThingsMod.MOD_ID, name), item);
    }

    public static void register() {
        // Рация лежит во вкладке «Инструменты и утилиты».
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS)
                .register(entries -> entries.add(WALKIE_TALKIE));
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.SPAWN_EGGS).register(entries -> {
            entries.add(DEMOGORGON_SPAWN_EGG);
            entries.add(DEMODOG_SPAWN_EGG);
            entries.add(MIND_FLAYER_SPAWN_EGG);
            entries.add(DEMOBAT_SPAWN_EGG);
            entries.add(DEMOSLUG_SPAWN_EGG);
            entries.add(FLAYED_HUMAN_SPAWN_EGG);
            entries.add(FLAYED_RATS_SPAWN_EGG);
            entries.add(FLAYED_BITS_SPAWN_EGG);
            entries.add(HOSPITAL_MONSTER_SPAWN_EGG);
            entries.add(MEAT_FLAYER_SPAWN_EGG);
            entries.add(VECNA_SPAWN_EGG);
            entries.add(SPORE_SHOOTER_SPAWN_EGG);
            entries.add(DEMODOG_NEST_SPAWN_EGG);
        });
    }
}
