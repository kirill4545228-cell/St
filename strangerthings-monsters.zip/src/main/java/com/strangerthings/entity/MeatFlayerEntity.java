package com.strangerthings.entity;

import com.strangerthings.ModEntities;
import com.strangerthings.entity.ai.ActionGoal;
import com.strangerthings.entity.ai.ChaseTargetGoal;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ItemStackParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * МЯСНОЙ ПОЖИРАТЕЛЬ — тяжёлый паук из плоти.
 *  • Метает куски плоти (4 варианта броска): урон + Замедление на расстоянии.
 *  • Казнь: если у цели меньше 35% здоровья и она рядом — почти мгновенно добивает и лечится.
 *  • При ранении отрывает куски плоти (живые «кусочки»).
 */
public class MeatFlayerEntity extends MonsterBase implements Hivemind {

    public MeatFlayerEntity(EntityType<? extends MeatFlayerEntity> type, World world) {
        super(type, world);
        this.experiencePoints = 60;
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return MonsterBase.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 160.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 12.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.24)
                .add(EntityAttributes.GENERIC_ARMOR, 6.0)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 0.8)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 32.0);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(1, new ActionGoal(this, "execute", 20)
                .range(0.0, 4.2).cooldown(200)
                .when(() -> this.getTarget() != null
                        && this.getTarget().getHealth() < this.getTarget().getMaxHealth() * 0.35f)
                .at(10, this::executeHit));
        for (String name : new String[]{"throwleftfront", "throwrightfront", "throwleftback", "throwrightback"}) {
            this.goalSelector.add(2, new ActionGoal(this, name, 14)
                    .range(4.5, 18.0).cooldown(90).chance(0.12f)
                    .at(7, this::throwMeat));
        }
        this.goalSelector.add(3, new ActionGoal(this, "attack", 12)
                .range(0.0, 3.6).cooldown(10).at(6, this::slash));
        this.goalSelector.add(4, new ChaseTargetGoal(this, 1.05));
        this.goalSelector.add(6, new WanderAroundFarGoal(this, 0.5));
        this.goalSelector.add(7, new LookAtEntityGoal(this, PlayerEntity.class, 14.0f));
        this.goalSelector.add(8, new LookAroundGoal(this));
        this.targetSelector.add(1, new RevengeGoal(this));
        this.targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    private void slash(LivingEntity target) {
        if (target != null && this.squaredDistanceTo(target) < 4.8 * 4.8) {
            this.tryAttack(target);
        }
    }

    private void throwMeat(LivingEntity target) {
        if (target == null || !this.canSee(target)) {
            return;
        }
        this.playSound(SoundEvents.ENTITY_SLIME_SQUISH, 2.0f, 0.6f);
        if (this.getWorld() instanceof ServerWorld sw) {
            Vec3d from = this.getPos().add(0.0, this.getHeight() * 0.7, 0.0);
            Vec3d to = target.getPos().add(0.0, target.getHeight() * 0.5, 0.0);
            ItemStackParticleEffect fx = new ItemStackParticleEffect(ParticleTypes.ITEM, new ItemStack(Items.ROTTEN_FLESH));
            for (int i = 0; i <= 10; i++) {
                Vec3d p = from.lerp(to, i / 10.0);
                sw.spawnParticles(fx, p.x, p.y, p.z, 2, 0.05, 0.05, 0.05, 0.02);
            }
        }
        if (target.damage(this.getDamageSources().mobAttack(this), 6.0f)) {
            target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 1));
        }
    }

    private void executeHit(LivingEntity target) {
        if (target == null || this.squaredDistanceTo(target) > 5.0 * 5.0) {
            return;
        }
        if (target.damage(this.getDamageSources().mobAttack(this), 30.0f)) {
            this.heal(10.0f);
            this.playSound(SoundEvents.ENTITY_RAVAGER_ATTACK, 2.0f, 0.5f);
        }
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        boolean hit = super.damage(source, amount);
        if (hit && this.isAlive() && this.getWorld() instanceof ServerWorld sw && this.getRandom().nextFloat() < 0.15f) {
            int near = sw.getEntitiesByClass(FlayedBitsEntity.class, this.getBoundingBox().expand(16.0),
                    FlayedBitsEntity::isAlive).size();
            if (near < 6) {
                FlayedBitsEntity b = ModEntities.FLAYED_BITS.create(sw);
                if (b != null) {
                    b.refreshPositionAndAngles(this.getX() + this.getRandom().nextDouble() * 2 - 1, this.getY(),
                            this.getZ() + this.getRandom().nextDouble() * 2 - 1, 0.0f, 0.0f);
                    b.setTarget(this.getTarget());
                    sw.spawnEntity(b);
                }
            }
        }
        return hit;
    }

    @Override
    protected void mobTick() {
        super.mobTick();
        if (this.age % 20 == 0) {
            Fx.shareTarget(this, 20.0);
        }
    }

    @Override
    protected int getDeathTicks() {
        return 30;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.ENTITY_RAVAGER_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_RAVAGER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_RAVAGER_DEATH;
    }
}
