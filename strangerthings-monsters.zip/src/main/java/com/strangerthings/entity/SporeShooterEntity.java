package com.strangerthings.entity;

import com.strangerthings.entity.ai.ActionGoal;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.world.World;

/**
 * СПОРОВЫЙ СТРЕЛОК — неподвижная «турель».
 *  • Плюёт спорами в игрока на расстоянии до 16 блоков: облако Тошноты, Яда и Замедления в точке цели.
 *  • Игроки рядом (4 блока) постоянно дышат спорами.
 *  • При смерти выпускает большое облако Слепоты и Тошноты.
 */
public class SporeShooterEntity extends MonsterBase {

    public SporeShooterEntity(EntityType<? extends SporeShooterEntity> type, World world) {
        super(type, world);
        this.experiencePoints = 10;
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return MonsterBase.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 30.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 1.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.0)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 1.0)
                .add(EntityAttributes.GENERIC_ARMOR, 2.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 18.0);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(1, new ActionGoal(this, "spray", 12)
                .range(0.0, 16.0).cooldown(80).chance(0.35f).at(5, this::spore));
        this.goalSelector.add(1, new ActionGoal(this, "spray2", 12)
                .range(0.0, 16.0).cooldown(80).chance(0.35f).at(5, this::spore));
        this.goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 16.0f));
        this.targetSelector.add(1, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    private void spore(LivingEntity target) {
        if (target == null) {
            return;
        }
        this.playSound(SoundEvents.ENTITY_SLIME_SQUISH, 1.5f, 0.5f);
        if (this.getWorld() instanceof ServerWorld sw) {
            sw.spawnParticles(ParticleTypes.SPORE_BLOSSOM_AIR, target.getX(), target.getY() + 1.0, target.getZ(),
                    30, 1.2, 0.8, 1.2, 0.02);
        }
        Fx.cloud(this.getWorld(), target.getX(), target.getY(), target.getZ(), 2.6f, 120,
                new StatusEffectInstance(StatusEffects.NAUSEA, 140, 0),
                new StatusEffectInstance(StatusEffects.POISON, 60, 0),
                new StatusEffectInstance(StatusEffects.SLOWNESS, 80, 0));
    }

    @Override
    protected void mobTick() {
        super.mobTick();
        if (this.age % 20 == 0) {
            for (PlayerEntity p : Fx.players(this, 4.0)) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 60, 0));
            }
        }
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public void onDeath(DamageSource source) {
        super.onDeath(source);
        Fx.cloud(this.getWorld(), this.getX(), this.getY(), this.getZ(), 3.5f, 140,
                new StatusEffectInstance(StatusEffects.BLINDNESS, 80, 0),
                new StatusEffectInstance(StatusEffects.NAUSEA, 120, 0));
    }

    @Override
    protected int getDeathTicks() {
        return 15;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_SLIME_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_SLIME_DEATH;
    }
}
