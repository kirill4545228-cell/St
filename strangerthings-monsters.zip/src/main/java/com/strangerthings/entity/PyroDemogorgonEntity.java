package com.strangerthings.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.world.World;

/** Демогоргон с моделью/анимациями автора Pyro (использовано с его разрешения). Поведение — как у обычного. */
public class PyroDemogorgonEntity extends DemogorgonEntity {
    public PyroDemogorgonEntity(EntityType<? extends PyroDemogorgonEntity> type, World world) {
        super(type, world);
    }

    @Override protected int roarLen() { return 20; }
    @Override protected int roarAt() { return 8; }
    @Override protected int attackLen() { return 13; }
    @Override protected int attackAt() { return 6; }
    @Override protected int getDeathTicks() { return 40; }
}
