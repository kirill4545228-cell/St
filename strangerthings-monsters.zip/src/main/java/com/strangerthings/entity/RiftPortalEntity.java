package com.strangerthings.entity;

import com.strangerthings.ModDimensions;
import com.strangerthings.ModEntities;
import net.fabricmc.fabric.api.dimension.v1.FabricDimensions;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.RegistryKey;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;
import net.minecraft.world.TeleportTarget;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * ТРЕЩИНА В ИЗНАНКУ — портал, который открывают «Силы Одиннадцать».
 * Живёт ограниченное время. Шагнул внутрь — оказался в параллельной точке другого мира
 * (Обычный мир <-> Изнанка), а на той стороне открывается обратная трещина.
 */
public class RiftPortalEntity extends MonsterBase {
    private static final Map<UUID, Long> COOLDOWN = new HashMap<>();

    private int life = 1200;
    private final Set<UUID> inside = new HashSet<>();

    public RiftPortalEntity(EntityType<? extends RiftPortalEntity> type, World world) {
        super(type, world);
        this.setInvulnerable(true);
        this.setNoGravity(true);
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return MonsterBase.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 10.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.0)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 1.0);
    }

    public void setLife(int ticks) {
        this.life = ticks;
    }

    /** Считать сущность «уже внутри» — чтобы портал не отправил её обратно сразу после прибытия. */
    public void markInside(Entity e) {
        this.inside.add(e.getUuid());
    }

    @Override
    protected void initGoals() {
    }

    @Override
    protected void mobTick() {
        super.mobTick();
        if (this.age == 2) {
            this.startAction("spawn", 20);
        }
        this.life--;
        if (this.life == 25) {
            this.startAction("despawn", 25);
        }
        if (this.life <= 0) {
            this.discard();
            return;
        }
        if (this.age > 20 && this.life > 25 && this.getWorld() instanceof ServerWorld sw) {
            this.tickTravel(sw);
        }
    }

    private void tickTravel(ServerWorld world) {
        Set<UUID> now = new HashSet<>();
        long time = world.getTime();
        for (LivingEntity e : world.getEntitiesByClass(LivingEntity.class, this.getBoundingBox().expand(0.0, 0.6, 0.0),
                x -> x != this && x.isAlive() && !(x instanceof RiftPortalEntity)
                        && !(x instanceof PlayerEntity p && p.isSpectator()))) {
            now.add(e.getUuid());
            if (this.inside.contains(e.getUuid())) {
                continue;
            }
            Long until = COOLDOWN.get(e.getUuid());
            if (until != null && until > time) {
                continue;
            }
            this.travel(world, e, time);
        }
        this.inside.clear();
        this.inside.addAll(now);
    }

    private void travel(ServerWorld from, LivingEntity e, long time) {
        RegistryKey<World> destKey = from.getRegistryKey() == ModDimensions.UPSIDE_DOWN
                ? World.OVERWORLD : ModDimensions.UPSIDE_DOWN;
        ServerWorld dest = from.getServer().getWorld(destKey);
        if (dest == null) {
            return;
        }
        int bx = MathHelper.floor(this.getX());
        int bz = MathHelper.floor(this.getZ());
        dest.getChunk(bx >> 4, bz >> 4); // прогрузить/сгенерировать чанк на той стороне
        int y = dest.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, bx, bz);
        Vec3d pos = new Vec3d(this.getX(), y, this.getZ());
        Entity moved = FabricDimensions.teleport(e, dest, new TeleportTarget(pos, Vec3d.ZERO, e.getYaw(), e.getPitch()));
        if (moved == null) {
            return;
        }
        COOLDOWN.put(moved.getUuid(), time + 60L);
        RiftPortalEntity back = ModEntities.RIFT_PORTAL.create(dest);
        if (back != null) {
            back.refreshPositionAndAngles(pos.x, pos.y, pos.z, this.getYaw(), 0.0f);
            back.setLife(600);
            back.markInside(moved);
            dest.spawnEntity(back);
        }
        dest.playSound(null, pos.x, pos.y, pos.z, SoundEvents.BLOCK_PORTAL_TRAVEL, SoundCategory.PLAYERS, 0.4f, 0.7f);
    }

    @Override
    public boolean isDisallowedInPeaceful() {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean isAttackable() {
        return false;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return null;
    }
}
