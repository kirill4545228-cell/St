package com.strangerthings.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.world.World;

/** Демопёс с моделью/анимациями автора Pyro (использовано с его разрешения). Поведение — как у обычного. */
public class PyroDemodogEntity extends DemodogEntity {
    public PyroDemodogEntity(EntityType<? extends PyroDemodogEntity> type, World world) {
        super(type, world);
    }

    @Override protected int howlLen() { return 20; }
    @Override protected int howlAt() { return 8; }
    @Override protected int swipeLen() { return 10; }
    @Override protected int swipeLeapAt() { return 1; }
    @Override protected int swipeHitAt() { return 6; }
    @Override protected int biteLen() { return 8; }
    @Override protected int biteAt() { return 4; }
    @Override protected int getDeathTicks() { return 30; }
}
