package com.strangerthings.entity;

import com.strangerthings.entity.ai.ActionGoal;
import com.strangerthings.entity.ai.ChaseTargetGoal;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.control.FlightMoveControl;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.FlyGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.pathing.BirdNavigation;
import net.minecraft.entity.ai.pathing.EntityNavigation;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.world.World;

/**
 * ДЕМОЛЕТУЧКА — летающая кровопийца.
 *  • Летает (не падает), атакует «налётом»: укус, затем отскок вверх.
 *  • Кровопийца: укус лечит её и накладывает Слабость.
 *  • Ночной охотник: ночью (или в тёмном месте) быстрее.
 */
public class DemobatEntity extends MonsterBase {

    public DemobatEntity(EntityType<? extends DemobatEntity> type, World world) {
        super(type, world);
        this.moveControl = new FlightMoveControl(this, 20, true);
        this.experiencePoints = 6;
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return MonsterBase.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 14.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 4.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.25)
                .add(EntityAttributes.GENERIC_FLYING_SPEED, 0.6)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 28.0);
    }

    @Override
    protected EntityNavigation createNavigation(World world) {
        BirdNavigation nav = new BirdNavigation(this, world);
        nav.setCanPathThroughDoors(false);
        nav.setCanSwim(false);
        nav.setCanEnterOpenDoors(true);
        return nav;
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(1, new ActionGoal(this, "attack", 8)
                .range(0.0, 2.6).cooldown(16)
                .at(3, this::drain)
                .at(5, t -> this.setVelocity(this.getVelocity().add(0.0, 0.45, 0.0))));
        this.goalSelector.add(2, new ChaseTargetGoal(this, 1.2));
        this.goalSelector.add(5, new FlyGoal(this, 1.0));
        this.goalSelector.add(7, new LookAroundGoal(this));
        this.targetSelector.add(1, new RevengeGoal(this));
        this.targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    private void drain(LivingEntity target) {
        if (target == null || this.squaredDistanceTo(target) > 3.5 * 3.5) {
            return;
        }
        if (this.tryAttack(target)) {
            this.heal(2.0f);
            target.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 80, 0));
        }
    }

    @Override
    protected void mobTick() {
        super.mobTick();
        if (this.age % 40 == 0 && this.getTarget() != null && this.getWorld().getLightLevel(this.getBlockPos()) <= 7) {
            this.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 60, 0, false, false));
        }
    }

    @Override
    public boolean isInvulnerableTo(DamageSource source) {
        return source.isOf(DamageTypes.FALL) || super.isInvulnerableTo(source);
    }

    @Override
    protected int getDeathTicks() {
        return 20;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.ENTITY_BAT_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_BAT_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_BAT_DEATH;
    }
}
