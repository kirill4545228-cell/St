package com.strangerthings.entity;

import com.strangerthings.ModEntities;
import com.strangerthings.entity.ai.ActionGoal;
import com.strangerthings.entity.ai.ChaseTargetGoal;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.world.World;

/**
 * ЗАРАЖЁННЫЙ ЧЕЛОВЕК.
 *  • Общий разум: делится целью с другими заражёнными рядом.
 *  • Заражение: удар вызывает Голод и Слабость.
 *  • Убитый им житель сам становится заражённым.
 */
public class FlayedHumanEntity extends MonsterBase implements Hivemind {

    public FlayedHumanEntity(EntityType<? extends FlayedHumanEntity> type, World world) {
        super(type, world);
        this.experiencePoints = 8;
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return MonsterBase.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 26.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 5.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.27)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 28.0);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(1, new ActionGoal(this, "attack", 9)
                .range(0.0, 2.4).cooldown(6).at(4, this::infect));
        this.goalSelector.add(3, new ChaseTargetGoal(this, 1.1));
        this.goalSelector.add(5, new WanderAroundFarGoal(this, 0.7));
        this.goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 10.0f));
        this.goalSelector.add(7, new LookAroundGoal(this));
        this.targetSelector.add(1, new RevengeGoal(this).setGroupRevenge());
        this.targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    private void infect(LivingEntity target) {
        if (target == null || this.squaredDistanceTo(target) > 3.4 * 3.4) {
            return;
        }
        if (this.tryAttack(target)) {
            target.addStatusEffect(new StatusEffectInstance(StatusEffects.HUNGER, 160, 0));
            target.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 100, 0));
        }
    }

    @Override
    protected void mobTick() {
        super.mobTick();
        if (this.age % 20 == 0) {
            Fx.shareTarget(this, 16.0);
        }
    }

    @Override
    public boolean onKilledOther(ServerWorld world, LivingEntity other) {
        boolean result = super.onKilledOther(world, other);
        if (other instanceof VillagerEntity) {
            FlayedHumanEntity h = ModEntities.FLAYED_HUMAN.create(world);
            if (h != null) {
                h.refreshPositionAndAngles(other.getX(), other.getY(), other.getZ(), other.getYaw(), 0.0f);
                world.spawnEntity(h);
            }
        }
        return result;
    }

    @Override
    protected int getDeathTicks() {
        return 20;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.ENTITY_ZOMBIE_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_ZOMBIE_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_ZOMBIE_DEATH;
    }
}
