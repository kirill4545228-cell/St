package com.strangerthings.entity;

import com.strangerthings.entity.ai.ActionGoal;
import com.strangerthings.entity.ai.ChaseTargetGoal;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.world.World;

import java.util.EnumSet;

/**
 * БОЛЬНИЧНЫЙ МОНСТР — засада.
 *  • Затаился: пока игрок не подойдёт ближе 6 блоков (или монстра не ударят), он неподвижен.
 *  • Визг: при пробуждении ослепляет и замедляет игроков рядом.
 *  • Плоть регенерирует, пока он ни с кем не дерётся.
 */
public class HospitalMonsterEntity extends MonsterBase {
    private boolean dormant = true;
    private boolean justWoke = false;

    public HospitalMonsterEntity(EntityType<? extends HospitalMonsterEntity> type, World world) {
        super(type, world);
        this.experiencePoints = 20;
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return MonsterBase.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 70.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 9.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.3)
                .add(EntityAttributes.GENERIC_ARMOR, 3.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 24.0);
    }

    /** Пока монстр затаился, он не двигается и ничего не делает. */
    private class DormantGoal extends Goal {
        DormantGoal() {
            this.setControls(EnumSet.of(Goal.Control.MOVE, Goal.Control.LOOK, Goal.Control.JUMP));
        }

        @Override
        public boolean canStart() {
            return dormant;
        }

        @Override
        public boolean shouldContinue() {
            return dormant;
        }
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new DormantGoal());
        this.goalSelector.add(1, new SwimGoal(this));
        this.goalSelector.add(1, new ActionGoal(this, "roar", 20).noTarget()
                .when(() -> this.justWoke).at(8, t -> this.scream()));
        this.goalSelector.add(2, new ActionGoal(this, "attack", 7)
                .range(0.0, 2.8).cooldown(8).at(3, this::maul));
        this.goalSelector.add(3, new ChaseTargetGoal(this, 1.15));
        this.goalSelector.add(5, new WanderAroundFarGoal(this, 0.6));
        this.goalSelector.add(7, new LookAroundGoal(this));
        this.targetSelector.add(1, new RevengeGoal(this));
        this.targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    private void wake() {
        if (this.dormant) {
            this.dormant = false;
            this.justWoke = true;
        }
    }

    private void scream() {
        this.justWoke = false;
        this.playSound(SoundEvents.ENTITY_ZOGLIN_ANGRY, 2.5f, 0.6f);
        for (PlayerEntity p : Fx.players(this, 12.0)) {
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 60, 0));
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 40, 1));
        }
    }

    private void maul(LivingEntity target) {
        if (target == null || this.squaredDistanceTo(target) > 3.8 * 3.8) {
            return;
        }
        if (this.tryAttack(target)) {
            target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 40, 0));
        }
    }

    @Override
    protected void mobTick() {
        super.mobTick();
        if (this.dormant) {
            if (!Fx.players(this, 6.0).isEmpty()) {
                this.wake();
            }
        } else if (this.getTarget() == null && this.age % 40 == 0) {
            this.heal(1.0f);
        }
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        this.wake();
        return super.damage(source, amount);
    }

    @Override
    protected int getDeathTicks() {
        return 30;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return this.dormant ? null : SoundEvents.ENTITY_ZOGLIN_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_ZOGLIN_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_ZOGLIN_DEATH;
    }
}
