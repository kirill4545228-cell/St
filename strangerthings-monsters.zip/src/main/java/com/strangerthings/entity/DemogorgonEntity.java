package com.strangerthings.entity;

import com.strangerthings.entity.ai.ActionGoal;
import com.strangerthings.entity.ai.ChaseTargetGoal;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * ДЕМОГОРГОН — одиночный охотник.
 *  • Охота в темноте: в тёмном месте (свет <= 7) получает Скорость.
 *  • Рёв: пугает всех игроков рядом (Замедление + Тьма + Слабость).
 *  • Лепестковый укус: сильный удар, накладывает Иссушение и лечит Демогоргона.
 *  • Уязвим к огню: урон от огня и лавы x2.
 */
public class DemogorgonEntity extends MonsterBase {

    public DemogorgonEntity(EntityType<? extends DemogorgonEntity> type, World world) {
        super(type, world);
        this.experiencePoints = 40;
    }

    // тайминги (в тиках) — переопределяются у вариантов с другой моделью
    protected int roarLen() { return 20; }
    protected int roarAt() { return 8; }
    protected int attackLen() { return 13; }
    protected int attackAt() { return 6; }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return MonsterBase.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 120.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 12.0)
                .add(EntityAttributes.GENERIC_ATTACK_KNOCKBACK, 1.5)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.30)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 0.7)
                .add(EntityAttributes.GENERIC_ARMOR, 4.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 40.0);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        // рёв (анимация roar 3.0 c = 60 тиков)
        this.goalSelector.add(1, new ActionGoal(this, "roar", this.roarLen())
                .range(4.0, 24.0).cooldown(500).chance(0.2f)
                .at(this.roarAt(), t -> this.roar()));
        // рывок (анимация dash 0.42 c = 9 тиков): бросок на цель издалека
        this.goalSelector.add(2, new ActionGoal(this, "dash", 9)
                .range(5.0, 14.0).cooldown(140).chance(0.25f)
                .at(2, this::lunge)
                .at(7, this::lungeHit));
        // укус лепестками (анимация attack 1.5 c = 30 тиков)
        this.goalSelector.add(2, new ActionGoal(this, "attack", this.attackLen())
                .range(0.0, 3.2).cooldown(10)
                .at(this.attackAt(), this::petalBite));
        this.goalSelector.add(3, new ChaseTargetGoal(this, 1.15));
        this.goalSelector.add(5, new WanderAroundFarGoal(this, 0.6));
        this.goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 14.0f));
        this.goalSelector.add(7, new LookAroundGoal(this));
        this.targetSelector.add(1, new RevengeGoal(this));
        this.targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    private void lunge(LivingEntity target) {
        if (target == null) {
            return;
        }
        Vec3d d = target.getPos().subtract(this.getPos());
        d = new Vec3d(d.x, 0.0, d.z).normalize().multiply(1.35);
        this.setVelocity(d.x, 0.4, d.z);
        this.playSound(SoundEvents.ENTITY_RAVAGER_ROAR, 1.5f, 1.2f);
    }

    private void lungeHit(LivingEntity target) {
        if (target != null && this.squaredDistanceTo(target) < 4.5 * 4.5) {
            this.tryAttack(target);
        }
    }

    private void petalBite(LivingEntity target) {
        if (target == null || this.squaredDistanceTo(target) > 4.5 * 4.5) {
            return;
        }
        if (this.tryAttack(target)) {
            this.heal((float) (this.getAttributeValue(EntityAttributes.GENERIC_ATTACK_DAMAGE) * 0.25));
            target.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER, 80, 0));
            this.playSound(SoundEvents.ENTITY_RAVAGER_ATTACK, 1.5f, 0.7f);
        }
    }

    private void roar() {
        this.playSound(SoundEvents.ENTITY_RAVAGER_ROAR, 3.0f, 0.6f);
        for (PlayerEntity p : this.getWorld().getEntitiesByClass(PlayerEntity.class,
                this.getBoundingBox().expand(18.0),
                pl -> pl.isAlive() && !pl.isCreative() && !pl.isSpectator())) {
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 100, 1));
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 120, 0));
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 100, 0));
        }
    }

    @Override
    protected void mobTick() {
        super.mobTick();
        // охота в темноте
        if (this.age % 20 == 0 && this.getTarget() != null) {
            int light = this.getWorld().getLightLevel(this.getBlockPos());
            if (light <= 7) {
                this.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 60, 1, false, false));
            }
        }
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        if (source.isIn(DamageTypeTags.IS_FIRE)) {
            amount *= 2.0f;
        }
        return super.damage(source, amount);
    }

    @Override
    protected int getDeathTicks() {
        return 40;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.ENTITY_RAVAGER_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_RAVAGER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_RAVAGER_DEATH;
    }
}
