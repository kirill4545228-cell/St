package com.strangerthings.entity;

import com.strangerthings.entity.ai.ActionGoal;
import com.strangerthings.entity.ai.ChaseTargetGoal;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.world.World;

/**
 * ВЕКНА — босс-колдун.
 *  • Казнь (execute): поднимает цель в воздух, накладывает Иссушение и наносит магический урон.
 *  • Толчок (push): волна, отбрасывающая всех вокруг.
 *  • Проклятие: лечится за каждого иссушённого игрока рядом; аура Тьмы.
 *  • Полоса босса (красная).
 */
public class VecnaEntity extends MonsterBase {
    private final ServerBossBar bossBar = new ServerBossBar(
            Text.translatable("entity.strangerthings.vecna"), BossBar.Color.RED, BossBar.Style.PROGRESS);

    public VecnaEntity(EntityType<? extends VecnaEntity> type, World world) {
        super(type, world);
        this.experiencePoints = 120;
        this.bossBar.setDarkenSky(false);
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return MonsterBase.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 250.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 14.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.25)
                .add(EntityAttributes.GENERIC_ARMOR, 8.0)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 0.9)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 40.0);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(1, new ActionGoal(this, "execute", 20)
                .range(2.0, 14.0).cooldown(260).chance(0.3f).at(10, this::execute));
        this.goalSelector.add(2, new ActionGoal(this, "push", 10)
                .range(0.0, 7.0).cooldown(120).chance(0.4f).at(5, t -> this.push()));
        this.goalSelector.add(3, new ActionGoal(this, "attack", 15)
                .range(0.0, 3.2).cooldown(8).at(8, this::melee));
        this.goalSelector.add(4, new ChaseTargetGoal(this, 1.1));
        this.goalSelector.add(6, new WanderAroundFarGoal(this, 0.5));
        this.goalSelector.add(7, new LookAtEntityGoal(this, PlayerEntity.class, 16.0f));
        this.goalSelector.add(8, new LookAroundGoal(this));
        this.targetSelector.add(1, new RevengeGoal(this));
        this.targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    private void melee(LivingEntity target) {
        if (target != null && this.squaredDistanceTo(target) < 4.4 * 4.4) {
            this.tryAttack(target);
        }
    }

    private void execute(LivingEntity target) {
        if (target == null || this.squaredDistanceTo(target) > 16.0 * 16.0) {
            return;
        }
        this.playSound(SoundEvents.ENTITY_EVOKER_CAST_SPELL, 2.5f, 0.5f);
        target.setVelocity(0.0, 0.9, 0.0);
        target.velocityModified = true;
        target.addStatusEffect(new StatusEffectInstance(StatusEffects.LEVITATION, 40, 0));
        target.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER, 100, 1));
        target.damage(this.getDamageSources().magic(), 10.0f);
    }

    private void push() {
        this.playSound(SoundEvents.ENTITY_WARDEN_SONIC_BOOM, 2.0f, 0.8f);
        if (this.getWorld() instanceof ServerWorld sw) {
            sw.spawnParticles(ParticleTypes.POOF, this.getX(), this.getY() + 1.0, this.getZ(), 40, 2.5, 0.5, 2.5, 0.1);
        }
        for (LivingEntity e : this.getWorld().getEntitiesByClass(LivingEntity.class,
                this.getBoundingBox().expand(8.0, 2.0, 8.0),
                x -> x != this && x.isAlive() && !(x instanceof MonsterBase))) {
            e.takeKnockback(1.6, this.getX() - e.getX(), this.getZ() - e.getZ());
            e.setVelocity(e.getVelocity().add(0.0, 0.4, 0.0));
            e.velocityModified = true;
            e.damage(this.getDamageSources().magic(), 6.0f);
            e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 1));
        }
    }

    @Override
    protected void mobTick() {
        super.mobTick();
        this.bossBar.setPercent(this.getHealth() / this.getMaxHealth());
        if (this.age % 20 == 0) {
            int cursed = 0;
            for (PlayerEntity p : Fx.players(this, 24.0)) {
                if (p.hasStatusEffect(StatusEffects.WITHER)) {
                    cursed++;
                }
            }
            if (cursed > 0) {
                this.heal(2.0f * cursed);
            }
        }
        if (this.age % 60 == 0) {
            for (PlayerEntity p : Fx.players(this, 12.0)) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 80, 0, true, false));
            }
        }
    }

    @Override
    public void onStartedTrackingBy(ServerPlayerEntity player) {
        super.onStartedTrackingBy(player);
        this.bossBar.addPlayer(player);
    }

    @Override
    public void onStoppedTrackingBy(ServerPlayerEntity player) {
        super.onStoppedTrackingBy(player);
        this.bossBar.removePlayer(player);
    }

    @Override
    public void remove(Entity.RemovalReason reason) {
        this.bossBar.clearPlayers();
        super.remove(reason);
    }

    @Override
    public boolean isInvulnerableTo(DamageSource source) {
        return source.isOf(DamageTypes.FALL) || super.isInvulnerableTo(source);
    }

    @Override
    protected int getDeathTicks() {
        return 40;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.ENTITY_EVOKER_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_EVOKER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_EVOKER_DEATH;
    }
}
