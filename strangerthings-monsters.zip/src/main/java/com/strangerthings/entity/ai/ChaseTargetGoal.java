package com.strangerthings.entity.ai;

import com.strangerthings.entity.MonsterBase;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.Goal;

import java.util.EnumSet;

/** Просто бежит к цели (атаки делают ActionGoal'ы с более высоким приоритетом). */
public class ChaseTargetGoal extends Goal {
    private final MonsterBase mob;
    private final double speed;
    private int repath;

    public ChaseTargetGoal(MonsterBase mob, double speed) {
        this.mob = mob;
        this.speed = speed;
        this.setControls(EnumSet.of(Goal.Control.MOVE));
    }

    @Override
    public boolean shouldRunEveryTick() {
        return true;
    }

    @Override
    public boolean canStart() {
        LivingEntity t = this.mob.getTarget();
        return t != null && t.isAlive() && !this.mob.isBusy();
    }

    @Override
    public boolean shouldContinue() {
        return this.canStart();
    }

    @Override
    public void start() {
        this.repath = 0;
    }

    @Override
    public void tick() {
        LivingEntity t = this.mob.getTarget();
        if (t == null) {
            return;
        }
        this.mob.getLookControl().lookAt(t, 30.0f, 30.0f);
        if (--this.repath <= 0) {
            this.repath = 4 + this.mob.getRandom().nextInt(4);
            this.mob.getNavigation().startMovingTo(t, this.speed);
        }
    }

    @Override
    public void stop() {
        this.mob.getNavigation().stop();
    }
}
