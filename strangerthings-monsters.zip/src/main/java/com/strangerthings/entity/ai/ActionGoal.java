package com.strangerthings.entity.ai;

import com.strangerthings.entity.MonsterBase;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.Goal;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/**
 * Универсальная «способность с анимацией»: включает анимацию на клиенте,
 * замораживает моба на время анимации и в нужные тики выполняет события
 * (удар, рёв, прыжок...). Все тайминги — в тиках (20 тиков = 1 секунда).
 */
public class ActionGoal extends Goal {
    private static class Event {
        final int tick;
        final Consumer<LivingEntity> action;
        boolean done;

        Event(int tick, Consumer<LivingEntity> action) {
            this.tick = tick;
            this.action = action;
        }
    }

    private final MonsterBase mob;
    private final String anim;
    private final int length;
    private final List<Event> events = new ArrayList<>();

    private double minDist = 0.0;
    private double maxDist = 64.0;
    private int cooldown = 0;
    private float chance = 1.0f;
    private boolean needsTarget = true;
    private BooleanSupplier condition = () -> true;

    private int nextAge = 0;
    private int startAge = 0;

    public ActionGoal(MonsterBase mob, String anim, int length) {
        this.mob = mob;
        this.anim = anim;
        this.length = length;
        this.setControls(EnumSet.of(Goal.Control.MOVE, Goal.Control.LOOK, Goal.Control.JUMP));
    }

    public ActionGoal range(double min, double max) {
        this.minDist = min;
        this.maxDist = max;
        return this;
    }

    public ActionGoal cooldown(int ticks) {
        this.cooldown = ticks;
        return this;
    }

    public ActionGoal chance(float chance) {
        this.chance = chance;
        return this;
    }

    public ActionGoal noTarget() {
        this.needsTarget = false;
        return this;
    }

    public ActionGoal when(BooleanSupplier condition) {
        this.condition = condition;
        return this;
    }

    public ActionGoal at(int tick, Consumer<LivingEntity> action) {
        this.events.add(new Event(tick, action));
        return this;
    }

    @Override
    public boolean shouldRunEveryTick() {
        return true;
    }

    @Override
    public boolean canStart() {
        if (!this.mob.isAlive() || this.mob.isBusy() || this.mob.age < this.nextAge) {
            return false;
        }
        LivingEntity target = this.mob.getTarget();
        if (this.needsTarget) {
            if (target == null || !target.isAlive()) {
                return false;
            }
            double d = this.mob.squaredDistanceTo(target);
            if (d < this.minDist * this.minDist || d > this.maxDist * this.maxDist) {
                return false;
            }
            if (!this.mob.getVisibilityCache().canSee(target)) {
                return false;
            }
        }
        if (!this.condition.getAsBoolean()) {
            return false;
        }
        return this.mob.getRandom().nextFloat() < this.chance;
    }

    @Override
    public boolean shouldContinue() {
        return this.mob.isAlive() && (this.mob.age - this.startAge) < this.length;
    }

    @Override
    public void start() {
        this.startAge = this.mob.age;
        for (Event e : this.events) {
            e.done = false;
        }
        this.mob.getNavigation().stop();
        this.mob.startAction(this.anim, this.length);
    }

    @Override
    public void tick() {
        LivingEntity target = this.mob.getTarget();
        if (target != null) {
            this.mob.getLookControl().lookAt(target, 40.0f, 40.0f);
        }
        int elapsed = this.mob.age - this.startAge;
        for (Event e : this.events) {
            if (!e.done && elapsed >= e.tick) {
                e.done = true;
                e.action.accept(target);
            }
        }
    }

    @Override
    public void stop() {
        this.nextAge = this.mob.age + this.cooldown;
        this.mob.stopAction();
    }
}
