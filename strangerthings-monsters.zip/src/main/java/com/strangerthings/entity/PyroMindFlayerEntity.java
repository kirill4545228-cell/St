package com.strangerthings.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.world.World;

/** Пожиратель разума с моделью/анимациями автора Pyro (использовано с его разрешения). */
public class PyroMindFlayerEntity extends MindFlayerEntity {
    public PyroMindFlayerEntity(EntityType<? extends PyroMindFlayerEntity> type, World world) {
        super(type, world);
    }

    @Override protected int roarLen() { return 20; }
    @Override protected int roarAt() { return 8; }
    @Override protected int slamLen() { return 30; }
    @Override protected int slamAt() { return 17; }
    @Override protected int pincerLen() { return 10; }
    @Override protected int pincerAt() { return 5; }
    @Override protected int biteLen() { return 13; }
    @Override protected int biteAt() { return 6; }
    @Override protected int getDeathTicks() { return 30; }
}
