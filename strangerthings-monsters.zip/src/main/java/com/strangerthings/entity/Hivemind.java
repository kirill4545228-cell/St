package com.strangerthings.entity;

/** Метка: «зараженные» мобы делятся целью друг с другом (общий разум). */
public interface Hivemind {
}
