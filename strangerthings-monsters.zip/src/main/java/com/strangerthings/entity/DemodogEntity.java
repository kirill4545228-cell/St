package com.strangerthings.entity;

import com.strangerthings.entity.ai.ActionGoal;
import com.strangerthings.entity.ai.ChaseTargetGoal;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * ДЕМОПЁС — стайный хищник.
 *  • Стая: чем больше демопсов рядом (от 3), тем сильнее каждый (Сила).
 *  • Вой: зовёт всех демопсов в радиусе 32 блоков на ту же цель и ускоряет их.
 *  • Чует кровь: нападает на игроков с health < 50% даже без прямой видимости.
 *  • Прыжок-удар (attack_swipe) и укус (attack_bite) с Замедлением.
 *  • Месть группой: если ударили одного — нападает вся стая.
 */
public class DemodogEntity extends MonsterBase {

    public DemodogEntity(EntityType<? extends DemodogEntity> type, World world) {
        super(type, world);
        this.experiencePoints = 12;
    }

    protected int howlLen() { return 20; }
    protected int howlAt() { return 8; }
    protected int swipeLen() { return 10; }
    protected int swipeLeapAt() { return 1; }
    protected int swipeHitAt() { return 6; }
    protected int biteLen() { return 8; }
    protected int biteAt() { return 4; }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return MonsterBase.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 36.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 6.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.36)
                .add(EntityAttributes.GENERIC_ARMOR, 1.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 32.0);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        // вой (roar 2.4 c = 48 тиков)
        this.goalSelector.add(1, new ActionGoal(this, "roar", this.howlLen())
                .range(0.0, 40.0).cooldown(600).chance(0.15f)
                .at(this.howlAt(), this::howl));
        // прыжок-удар (attack_swipe 1.4 c = 28 тиков)
        this.goalSelector.add(2, new ActionGoal(this, "attack_swipe", this.swipeLen())
                .range(2.8, 8.0).cooldown(120).chance(0.4f)
                .at(this.swipeLeapAt(), this::leap)
                .at(this.swipeHitAt(), t -> this.hit(t, 1.4, 3.4)));
        // укус (attack_bite 1.1 c = 22 тика)
        this.goalSelector.add(3, new ActionGoal(this, "attack_bite", this.biteLen())
                .range(0.0, 2.6).cooldown(8)
                .at(this.biteAt(), t -> this.hit(t, 1.0, 3.0)));
        this.goalSelector.add(4, new ChaseTargetGoal(this, 1.2));
        this.goalSelector.add(6, new WanderAroundFarGoal(this, 0.7));
        this.goalSelector.add(7, new LookAtEntityGoal(this, PlayerEntity.class, 12.0f));
        this.goalSelector.add(8, new LookAroundGoal(this));
        this.targetSelector.add(1, new RevengeGoal(this).setGroupRevenge());
        this.targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
        // чует кровь: раненые игроки (<50% здоровья), без проверки видимости
        this.targetSelector.add(3, new ActiveTargetGoal<>(this, PlayerEntity.class, 10, false, false,
                p -> p.getHealth() < p.getMaxHealth() * 0.5f));
    }

    private void hit(LivingEntity target, double dmgMul, double reach) {
        if (target == null || this.squaredDistanceTo(target) > reach * reach) {
            return;
        }
        if (this.tryAttack(target)) {
            target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 0));
        }
    }

    private void leap(LivingEntity target) {
        if (target == null) {
            return;
        }
        Vec3d d = target.getPos().subtract(this.getPos());
        d = new Vec3d(d.x, 0.0, d.z).normalize().multiply(1.05);
        this.setVelocity(d.x, 0.5, d.z);
        this.playSound(SoundEvents.ENTITY_WOLF_GROWL, 1.5f, 0.6f);
    }

    private void howl(LivingEntity target) {
        this.playSound(SoundEvents.ENTITY_WOLF_HOWL, 2.5f, 0.55f);
        if (target == null) {
            return;
        }
        for (DemodogEntity d : this.getWorld().getEntitiesByClass(DemodogEntity.class,
                this.getBoundingBox().expand(32.0), x -> x != this && x.isAlive())) {
            d.setTarget(target);
            d.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 200, 1));
        }
    }

    @Override
    protected void mobTick() {
        super.mobTick();
        // бонус стаи
        if (this.age % 20 == 0 && this.getTarget() != null) {
            int pack = this.getWorld().getEntitiesByClass(DemodogEntity.class,
                    this.getBoundingBox().expand(12.0), x -> x.isAlive()).size();
            if (pack >= 3) {
                int amp = Math.min(pack - 3, 2);
                this.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 60, amp, false, false));
            }
        }
    }

    @Override
    protected int getDeathTicks() {
        return 30;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.ENTITY_WOLF_GROWL;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_WOLF_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_WOLF_DEATH;
    }
}
