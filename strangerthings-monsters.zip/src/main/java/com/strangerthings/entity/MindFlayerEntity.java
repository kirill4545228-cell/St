package com.strangerthings.entity;

import com.strangerthings.ModEntities;
import com.strangerthings.entity.ai.ActionGoal;
import com.strangerthings.entity.ai.ChaseTargetGoal;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * ПОЖИРАТЕЛЬ РАЗУМА — босс.
 *  • Полоса босса (фиолетовая).
 *  • Власть над разумом: рёв, после которого все игроки в зоне видимости получают
 *    Замедление, Тошноту и Тьму, их притягивает к монстру и бьёт психический урон.
 *  • Зов стаи: при здоровье ниже 70% призывает демопсов (не больше 4 рядом).
 *  • Удар о землю (attack_slam): волна урона и подброс вокруг.
 *  • Клешня (attack_pincer): хватает цель, подбрасывает и наносит урон.
 *  • Укус (attack_bite): лечит босса.
 *  • Аура Тьмы вокруг него; не получает урон от падения и удушья.
 */
public class MindFlayerEntity extends MonsterBase {
    private final ServerBossBar bossBar = new ServerBossBar(
            Text.translatable("entity.strangerthings.mind_flayer"),
            BossBar.Color.PURPLE, BossBar.Style.PROGRESS);

    public MindFlayerEntity(EntityType<? extends MindFlayerEntity> type, World world) {
        super(type, world);
        this.experiencePoints = 150;
        this.bossBar.setDarkenSky(false);
    }

    protected int roarLen() { return 48; }
    protected int roarAt() { return 20; }
    protected int slamLen() { return 30; }
    protected int slamAt() { return 17; }
    protected int pincerLen() { return 26; }
    protected int pincerAt() { return 14; }
    protected int biteLen() { return 24; }
    protected int biteAt() { return 11; }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return MonsterBase.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 300.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 16.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.26)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 1.0)
                .add(EntityAttributes.GENERIC_ARMOR, 10.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 48.0);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        // власть над разумом (roar 2.4 c = 48 тиков)
        this.goalSelector.add(1, new ActionGoal(this, "roar", this.roarLen())
                .range(0.0, 28.0).cooldown(260).chance(0.3f)
                .at(this.roarAt(), t -> this.mindFlay()));
        // зов стаи (тоже roar)
        this.goalSelector.add(1, new ActionGoal(this, "roar", this.roarLen())
                .range(0.0, 40.0).cooldown(600).chance(0.3f)
                .when(() -> this.getHealth() < this.getMaxHealth() * 0.7f && this.countPack() < 4)
                .at(this.roarAt(), t -> this.summonPack()));
        // удар о землю (attack_slam 1.5 c = 30 тиков)
        this.goalSelector.add(2, new ActionGoal(this, "attack_slam", this.slamLen())
                .range(0.0, 5.5).cooldown(100).chance(0.5f)
                .at(this.slamAt(), t -> this.slam()));
        // клешня (attack_pincer 1.3 c = 26 тиков)
        this.goalSelector.add(2, new ActionGoal(this, "attack_pincer", this.pincerLen())
                .range(0.0, 4.5).cooldown(140).chance(0.5f)
                .at(this.pincerAt(), this::pincer));
        // укус (attack_bite 1.2 c = 24 тика)
        this.goalSelector.add(3, new ActionGoal(this, "attack_bite", this.biteLen())
                .range(0.0, 3.6).cooldown(12)
                .at(this.biteAt(), this::bite));
        this.goalSelector.add(4, new ChaseTargetGoal(this, 1.1));
        this.goalSelector.add(6, new WanderAroundFarGoal(this, 0.5));
        this.goalSelector.add(7, new LookAtEntityGoal(this, PlayerEntity.class, 16.0f));
        this.goalSelector.add(8, new LookAroundGoal(this));
        this.targetSelector.add(1, new RevengeGoal(this));
        this.targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    private int countPack() {
        return this.getWorld().getEntitiesByClass(DemodogEntity.class,
                this.getBoundingBox().expand(32.0), DemodogEntity::isAlive).size();
    }

    private void mindFlay() {
        this.playSound(SoundEvents.ENTITY_WARDEN_ROAR, 3.0f, 0.6f);
        Vec3d c = this.getPos();
        for (PlayerEntity p : this.getWorld().getEntitiesByClass(PlayerEntity.class,
                this.getBoundingBox().expand(24.0),
                pl -> pl.isAlive() && !pl.isCreative() && !pl.isSpectator() && this.canSee(pl))) {
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 100, 2));
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 160, 0));
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 140, 0));
            Vec3d pull = c.subtract(p.getPos());
            pull = new Vec3d(pull.x, 0.0, pull.z).normalize().multiply(0.9);
            p.setVelocity(pull.x, 0.25, pull.z);
            p.velocityModified = true;
            p.damage(this.getDamageSources().magic(), 3.0f);
        }
    }

    private void summonPack() {
        if (!(this.getWorld() instanceof ServerWorld sw)) {
            return;
        }
        this.playSound(SoundEvents.ENTITY_WOLF_HOWL, 3.0f, 0.5f);
        for (int i = 0; i < 2; i++) {
            DemodogEntity d = ModEntities.DEMODOG.create(sw);
            if (d == null) {
                continue;
            }
            double a = this.getRandom().nextDouble() * Math.PI * 2.0;
            d.refreshPositionAndAngles(this.getX() + Math.cos(a) * 3.5, this.getY(),
                    this.getZ() + Math.sin(a) * 3.5, this.getRandom().nextFloat() * 360.0f, 0.0f);
            d.setTarget(this.getTarget());
            sw.spawnEntity(d);
        }
    }

    private void slam() {
        this.playSound(SoundEvents.ENTITY_GENERIC_EXPLODE, 2.0f, 0.6f);
        if (this.getWorld() instanceof ServerWorld sw) {
            sw.spawnParticles(ParticleTypes.POOF, this.getX(), this.getY() + 0.2, this.getZ(),
                    40, 2.5, 0.2, 2.5, 0.05);
        }
        for (LivingEntity e : this.getWorld().getEntitiesByClass(LivingEntity.class,
                this.getBoundingBox().expand(5.0, 1.0, 5.0),
                x -> x != this && x.isAlive() && !(x instanceof MonsterBase))) {
            e.damage(this.getDamageSources().mobAttack(this), 12.0f);
            e.takeKnockback(1.2, this.getX() - e.getX(), this.getZ() - e.getZ());
            e.setVelocity(e.getVelocity().add(0.0, 0.5, 0.0));
            e.velocityModified = true;
        }
    }

    private void pincer(LivingEntity target) {
        if (target == null || this.squaredDistanceTo(target) > 5.5 * 5.5) {
            return;
        }
        if (target.damage(this.getDamageSources().mobAttack(this), 10.0f)) {
            target.setVelocity(0.0, 1.1, 0.0);
            target.velocityModified = true;
            target.addStatusEffect(new StatusEffectInstance(StatusEffects.LEVITATION, 30, 0));
            this.playSound(SoundEvents.ENTITY_IRON_GOLEM_ATTACK, 2.0f, 0.5f);
        }
    }

    private void bite(LivingEntity target) {
        if (target == null || this.squaredDistanceTo(target) > 4.6 * 4.6) {
            return;
        }
        if (this.tryAttack(target)) {
            this.heal((float) (this.getAttributeValue(EntityAttributes.GENERIC_ATTACK_DAMAGE) * 0.3));
        }
    }

    @Override
    protected void mobTick() {
        super.mobTick();
        this.bossBar.setPercent(this.getHealth() / this.getMaxHealth());
        // аура тьмы
        if (this.age % 40 == 0) {
            for (PlayerEntity p : this.getWorld().getEntitiesByClass(PlayerEntity.class,
                    this.getBoundingBox().expand(16.0),
                    pl -> pl.isAlive() && !pl.isCreative() && !pl.isSpectator())) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 80, 0, true, false));
            }
        }
    }

    @Override
    public void onStartedTrackingBy(ServerPlayerEntity player) {
        super.onStartedTrackingBy(player);
        this.bossBar.addPlayer(player);
    }

    @Override
    public void onStoppedTrackingBy(ServerPlayerEntity player) {
        super.onStoppedTrackingBy(player);
        this.bossBar.removePlayer(player);
    }

    @Override
    public void remove(Entity.RemovalReason reason) {
        this.bossBar.clearPlayers();
        super.remove(reason);
    }

    @Override
    public boolean isInvulnerableTo(DamageSource source) {
        return source.isOf(DamageTypes.FALL) || source.isOf(DamageTypes.IN_WALL)
                || source.isOf(DamageTypes.DROWN) || super.isInvulnerableTo(source);
    }

    @Override
    protected int getDeathTicks() {
        return 55;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.ENTITY_WARDEN_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_WARDEN_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_WARDEN_DEATH;
    }
}
