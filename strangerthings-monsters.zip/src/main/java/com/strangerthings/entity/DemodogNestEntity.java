package com.strangerthings.entity;

import com.strangerthings.ModEntities;
import com.strangerthings.entity.ai.ActionGoal;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.world.World;

/**
 * ГНЕЗДО ДЕМОПСОВ — неподвижный «спавнер».
 *  • Пока игрок рядом (24 блока), раз в 20 секунд выпускает демопса (не больше 3 живых рядом).
 *  • Когда его разрушают, из него выбегает ещё пара демопсов.
 */
public class DemodogNestEntity extends MonsterBase {

    public DemodogNestEntity(EntityType<? extends DemodogNestEntity> type, World world) {
        super(type, world);
        this.experiencePoints = 15;
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return MonsterBase.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 40.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.0)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 1.0)
                .add(EntityAttributes.GENERIC_ARMOR, 4.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 28.0);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(1, new ActionGoal(this, "spawn", 10).noTarget().cooldown(400)
                .when(() -> !Fx.players(this, 24.0).isEmpty() && this.dogsNearby() < 3)
                .at(5, t -> this.releaseDog()));
    }

    private int dogsNearby() {
        return this.getWorld().getEntitiesByClass(DemodogEntity.class,
                this.getBoundingBox().expand(24.0), DemodogEntity::isAlive).size();
    }

    private void releaseDog() {
        if (!(this.getWorld() instanceof ServerWorld sw)) {
            return;
        }
        DemodogEntity d = ModEntities.DEMODOG.create(sw);
        if (d == null) {
            return;
        }
        double a = this.getRandom().nextDouble() * Math.PI * 2.0;
        d.refreshPositionAndAngles(this.getX() + Math.cos(a) * 1.8, this.getY(), this.getZ() + Math.sin(a) * 1.8,
                this.getRandom().nextFloat() * 360.0f, 0.0f);
        PlayerEntity p = sw.getClosestPlayer(this, 24.0);
        if (p != null && !p.isCreative() && !p.isSpectator()) {
            d.setTarget(p);
        }
        sw.spawnEntity(d);
        this.playSound(SoundEvents.ENTITY_SLIME_SQUISH, 1.5f, 0.6f);
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public void onDeath(DamageSource source) {
        super.onDeath(source);
        if (!this.getWorld().isClient()) {
            this.releaseDog();
            this.releaseDog();
        }
    }

    @Override
    protected int getDeathTicks() {
        return 25;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_SLIME_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_SLIME_DEATH;
    }
}
