package com.strangerthings.entity;

import com.strangerthings.ModEntities;
import com.strangerthings.entity.ai.ActionGoal;
import com.strangerthings.entity.ai.ChaseTargetGoal;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.world.World;

/**
 * ЗАРАЖЁННЫЕ КРЫСЫ — быстрая стая.
 *  • Грызут: Голод II и Яд.
 *  • Размножаются: раненая крыса (меньше 50% HP) может породить ещё одну (до 8 рядом).
 *  • Общий разум и быстрый бег.
 */
public class FlayedRatsEntity extends MonsterBase implements Hivemind {

    public FlayedRatsEntity(EntityType<? extends FlayedRatsEntity> type, World world) {
        super(type, world);
        this.experiencePoints = 2;
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return MonsterBase.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 8.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 2.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.36)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 24.0);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(1, new ActionGoal(this, "attack", 8)
                .range(0.0, 1.9).cooldown(5).at(3, this::gnaw));
        this.goalSelector.add(3, new ChaseTargetGoal(this, 1.25));
        this.goalSelector.add(5, new WanderAroundFarGoal(this, 0.8));
        this.goalSelector.add(7, new LookAroundGoal(this));
        this.targetSelector.add(1, new RevengeGoal(this).setGroupRevenge());
        this.targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    private void gnaw(LivingEntity target) {
        if (target == null || this.squaredDistanceTo(target) > 2.6 * 2.6) {
            return;
        }
        if (this.tryAttack(target)) {
            target.addStatusEffect(new StatusEffectInstance(StatusEffects.HUNGER, 100, 1));
            target.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 40, 0));
        }
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        boolean hit = super.damage(source, amount);
        if (hit && this.isAlive() && !this.getWorld().isClient() && this.getHealth() < this.getMaxHealth() * 0.5f
                && this.getRandom().nextFloat() < 0.25f && this.getWorld() instanceof ServerWorld sw) {
            int near = sw.getEntitiesByClass(FlayedRatsEntity.class, this.getBoundingBox().expand(12.0),
                    FlayedRatsEntity::isAlive).size();
            if (near < 8) {
                FlayedRatsEntity r = ModEntities.FLAYED_RATS.create(sw);
                if (r != null) {
                    r.refreshPositionAndAngles(this.getX() + 0.5, this.getY(), this.getZ() + 0.5,
                            this.getRandom().nextFloat() * 360.0f, 0.0f);
                    r.setTarget(this.getTarget());
                    sw.spawnEntity(r);
                }
            }
        }
        return hit;
    }

    @Override
    protected void mobTick() {
        super.mobTick();
        if (this.age % 20 == 0) {
            Fx.shareTarget(this, 14.0);
        }
    }

    @Override
    protected int getDeathTicks() {
        return 10;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.ENTITY_SILVERFISH_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_SILVERFISH_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_SILVERFISH_DEATH;
    }
}
