package com.strangerthings.entity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.world.World;

/**
 * Общая база для монстров мода: синхронизирует с клиентом, какую анимацию
 * («attack», «roar», «attack_bite»...) сейчас проигрывать, и охотится ли моб.
 * Имена анимаций берутся из .bbmodel (после «animation.xxx.»).
 */
public abstract class MonsterBase extends HostileEntity {
    private static final TrackedData<String> ACTION =
            DataTracker.registerData(MonsterBase.class, TrackedDataHandlerRegistry.STRING);
    private static final TrackedData<Boolean> HUNTING =
            DataTracker.registerData(MonsterBase.class, TrackedDataHandlerRegistry.BOOLEAN);

    private int actionTicks;
    /** Только клиент: значение age в момент начала текущей анимации. */
    public int clientActionStart;

    protected MonsterBase(EntityType<? extends MonsterBase> type, World world) {
        super(type, world);
        this.setPersistent();
    }

    @Override
    protected void initDataTracker() {
        super.initDataTracker();
        this.dataTracker.startTracking(ACTION, "");
        this.dataTracker.startTracking(HUNTING, false);
    }

    @Override
    public void onTrackedDataSet(TrackedData<?> data) {
        super.onTrackedDataSet(data);
        if (data == ACTION && this.getWorld().isClient()) {
            this.clientActionStart = this.age;
        }
    }

    public String getAction() {
        return this.dataTracker.get(ACTION);
    }

    public boolean isHunting() {
        return this.dataTracker.get(HUNTING);
    }

    public boolean isBusy() {
        return this.actionTicks > 0;
    }

    public void startAction(String name, int ticks) {
        this.actionTicks = ticks;
        this.dataTracker.set(ACTION, name);
    }

    public void stopAction() {
        this.actionTicks = 0;
        this.dataTracker.set(ACTION, "");
    }

    /** Сколько тиков «лежит» труп (идёт анимация death). */
    protected int getDeathTicks() {
        return 50;
    }

    @Override
    protected void mobTick() {
        super.mobTick();
        if (this.actionTicks > 0 && --this.actionTicks == 0) {
            this.dataTracker.set(ACTION, "");
        }
        boolean hunting = this.getTarget() != null;
        if (hunting != this.dataTracker.get(HUNTING)) {
            this.dataTracker.set(HUNTING, hunting);
        }
    }

    @Override
    protected void updatePostDeath() {
        ++this.deathTime;
        if (this.deathTime >= this.getDeathTicks() && !this.getWorld().isClient() && !this.isRemoved()) {
            this.getWorld().sendEntityStatus(this, (byte) 60);
            this.remove(Entity.RemovalReason.KILLED);
        }
    }

    @Override
    public boolean canImmediatelyDespawn(double distanceSquared) {
        return false;
    }
}
