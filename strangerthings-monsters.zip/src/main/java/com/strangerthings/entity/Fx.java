package com.strangerthings.entity;

import net.minecraft.entity.AreaEffectCloudEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.world.World;

import java.util.List;

/** Мелкие общие помощники для способностей мобов. */
public final class Fx {
    private Fx() {
    }

    public static List<PlayerEntity> players(Entity e, double radius) {
        return e.getWorld().getEntitiesByClass(PlayerEntity.class, e.getBoundingBox().expand(radius),
                p -> p.isAlive() && !p.isCreative() && !p.isSpectator());
    }

    /** Облако с эффектами, которое медленно рассеивается. */
    public static void cloud(World world, double x, double y, double z, float radius, int duration,
                             StatusEffectInstance... effects) {
        if (world.isClient()) {
            return;
        }
        AreaEffectCloudEntity c = new AreaEffectCloudEntity(world, x, y, z);
        c.setRadius(radius);
        c.setDuration(duration);
        c.setWaitTime(0);
        c.setRadiusGrowth(-radius / duration);
        for (StatusEffectInstance ef : effects) {
            c.addEffect(ef);
        }
        world.spawnEntity(c);
    }

    /** Общий разум: свободные «зараженные» рядом берут цель того, у кого она есть. */
    public static void shareTarget(MonsterBase self, double radius) {
        LivingEntity t = self.getTarget();
        if (t == null || !t.isAlive()) {
            return;
        }
        for (MonsterBase m : self.getWorld().getEntitiesByClass(MonsterBase.class,
                self.getBoundingBox().expand(radius),
                x -> x != self && x.isAlive() && x instanceof Hivemind && x.getTarget() == null)) {
            m.setTarget(t);
        }
    }
}
