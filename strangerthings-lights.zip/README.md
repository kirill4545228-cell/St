# Stranger Things — Fabric 1.20.1

## Что внутри
- **Рация** `strangerthings:walkie_talkie` — шипит помехами при ПКМ. Крафт:
  ` N ` / `IRI` / `ICI` (N — железный самородок, I — железный слиток, R — красная пыль, C — медный слиток).
- **Рождественские огни** `strangerthings:christmas_lights` — вешаются на боковую стену как лестница,
  светят (уровень 12), лампочки переливаются (анимированная текстура). Крафт (даёт 2):
  `SSS` / `RYG` / `DDD` (нить, красный/жёлтый/зелёный краситель, светящаяся пыль).
- `blockbench/` — исходники моделей (.bbmodel).

## Сборка на GitHub
Залей проект (или этот zip) в репозиторий — `.github/workflows/build.yml` сам распакует и соберёт jar
(Actions → Artifacts).

## Если у тебя уже есть репозиторий мода
Скопируй:
- `java/com/strangerthings/`: `block/ChristmasLightsBlock.java`, `item/WalkieTalkieItem.java`,
  `ModBlocks.java`, `ModItems.java`, `ModSounds.java`
- в `onInitialize()`: `ModSounds.register(); ModBlocks.register(); ModItems.register();`
- папки `assets/strangerthings/` и `data/strangerthings/` целиком
  (в `lang/*.json` допиши ключи, если файлы уже есть)
Если modid или пакет другие — замени `strangerthings` в Java-файлах и переименуй папки.
