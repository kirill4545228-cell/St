package com.strangerthings;

import com.strangerthings.item.WalkieTalkieItem;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModItems {
    public static final Item WALKIE_TALKIE = register("walkie_talkie",
            new WalkieTalkieItem(new FabricItemSettings().maxCount(1)));

    private static Item register(String name, Item item) {
        return Registry.register(Registries.ITEM, new Identifier(StrangerThingsMod.MOD_ID, name), item);
    }

    public static void register() {
        // Рация лежит во вкладке «Инструменты и утилиты».
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS_AND_UTILITIES)
                .register(entries -> entries.add(WALKIE_TALKIE));
    }
}
